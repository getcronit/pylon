'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const gqty = require('gqty');
const React = require('react');

const IS_BROWSER = typeof window !== "undefined";
const useIsomorphicLayoutEffect = IS_BROWSER ? React.useLayoutEffect : React.useEffect;
const legacyFetchPolicyMap = {
  "cache-first": "force-cache",
  "network-only": "no-cache",
  "cache-and-network": "default",
  "no-cache": "no-store"
};
const translateFetchPolicy = (fetchPolicy) => {
  var _a;
  return (_a = legacyFetchPolicyMap[fetchPolicy]) != null ? _a : "default";
};
const useExtractedSelections = (input) => {
  const [selections] = React.useState(() => /* @__PURE__ */ new Set());
  React.useEffect(() => {
    var _a, _b;
    selections.clear();
    if (input === void 0) return;
    for (const it of input) {
      (_b = it instanceof gqty.Selection ? it : (_a = gqty.$meta(it)) == null ? void 0 : _a.selection) == null ? void 0 : _b.getLeafNodes().forEach((selection) => selections.add(selection));
    }
  }, [input, input == null ? void 0 : input.length]);
  return selections;
};
function toSetIfNeeded(list) {
  return Array.isArray(list) ? new Set(list) : list;
}
function isSelectionIncluded(selection, selectionList) {
  const setSelectionList = toSetIfNeeded(selectionList);
  if (setSelectionList.has(selection)) return true;
  for (const listValue of selectionList) {
    if (setSelectionList.has(listValue)) return true;
  }
  return false;
}
function isAnySelectionIncluded(selectionsToCheck, selectionsList) {
  const setSelectionList = toSetIfNeeded(selectionsList);
  for (const selection of selectionsToCheck) {
    if (isSelectionIncluded(selection, setSelectionList)) return true;
  }
  return false;
}
function isAnySelectionIncludedInMatrix(selectionsToCheck, selectionsMatrix) {
  const selectionsToCheckSet = toSetIfNeeded(selectionsToCheck);
  for (const group of selectionsMatrix) {
    if (isAnySelectionIncluded(selectionsToCheckSet, group)) return true;
  }
  return false;
}
const coreHelpers = {
  prepass: gqty.prepass,
  getFields: gqty.getFields,
  getArrayFields: gqty.getArrayFields,
  selectFields: gqty.selectFields,
  castNotSkeleton: gqty.castNotSkeleton,
  castNotSkeletonDeep: gqty.castNotSkeletonDeep
};
function uniqBy(list, cb) {
  const uniqList = /* @__PURE__ */ new Map();
  for (const value of list) {
    const key = cb ? cb(value) : value;
    if (uniqList.has(key)) continue;
    uniqList.set(key, value);
  }
  return Array.from(uniqList.values());
}
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function sortBy(list, cb, order = "asc") {
  const orderedList = Array.from(list);
  orderedList.sort((a, b) => compare(cb(a), cb(b)));
  if (order === "desc") orderedList.reverse();
  return orderedList;
}

exports.IS_BROWSER = IS_BROWSER;
exports.coreHelpers = coreHelpers;
exports.isAnySelectionIncluded = isAnySelectionIncluded;
exports.isAnySelectionIncludedInMatrix = isAnySelectionIncludedInMatrix;
exports.isSelectionIncluded = isSelectionIncluded;
exports.legacyFetchPolicyMap = legacyFetchPolicyMap;
exports.sortBy = sortBy;
exports.toSetIfNeeded = toSetIfNeeded;
exports.translateFetchPolicy = translateFetchPolicy;
exports.uniqBy = uniqBy;
exports.useExtractedSelections = useExtractedSelections;
exports.useIsomorphicLayoutEffect = useIsomorphicLayoutEffect;
