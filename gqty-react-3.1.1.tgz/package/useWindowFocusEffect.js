'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const React = require('react');

const useWindowFocusEffect = (fn, deps = []) => {
  React.useEffect(() => {
    var _a, _b;
    const visibilityChangeFn = () => {
      var _a2;
      if (((_a2 = globalThis.document) == null ? void 0 : _a2.visibilityState) === "visible") {
        fn();
      }
    };
    (_a = globalThis.addEventListener) == null ? void 0 : _a.call(globalThis, "visibilitychange", visibilityChangeFn);
    (_b = globalThis.addEventListener) == null ? void 0 : _b.call(globalThis, "focus", visibilityChangeFn);
    return () => {
      var _a2, _b2;
      (_a2 = globalThis.removeEventListener) == null ? void 0 : _a2.call(globalThis, "visibilitychange", visibilityChangeFn);
      (_b2 = globalThis.removeEventListener) == null ? void 0 : _b2.call(globalThis, "focus", visibilityChangeFn);
    };
  }, deps.concat(fn));
};

exports.useWindowFocusEffect = useWindowFocusEffect;
