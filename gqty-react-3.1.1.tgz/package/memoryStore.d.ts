/**
 * An in-memory store for useSyncExternalStore.
 */
export declare const createMemoryStore: <T>(initialValue: T) => {
    add: (value: Partial<T>) => void;
    get: () => Readonly<T>;
    set: (value: T) => void;
    subscribe: (listener: () => void) => () => boolean;
};
