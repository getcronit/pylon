import { type DependencyList } from 'react';
export declare const useOnlineEffect: (fn: (...args: unknown[]) => unknown, deps?: DependencyList) => void;
