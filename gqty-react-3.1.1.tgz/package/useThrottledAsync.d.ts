export type AsyncStatus = 'loading' | 'success' | 'error' | 'not-executed';
export type AsyncState<Result> = {
    status: 'not-executed';
    error: undefined;
    result: Result;
} | {
    status: 'success';
    error: undefined;
    result: Result;
} | {
    status: 'error';
    error: Error;
    result: Result;
} | {
    status: AsyncStatus;
    error: Error | undefined;
    result: Result;
};
export interface UseAsyncActions<Result, Args extends unknown[] = unknown[]> {
    /**
     * Reset state to initial.
     */
    reset: () => void;
    /**
     * Execute the async function manually.
     */
    execute: (...args: Args) => Promise<Result>;
}
export interface UseAsyncMeta<Result, Args extends unknown[] = unknown[]> {
    /**
     * Latest promise returned from the async function.
     */
    promise: Promise<Result> | undefined;
    /**
     * List of arguments applied to the latest async function invocation.
     */
    lastArgs: Args | undefined;
}
/**
 * **Modified version of `useAsync` in `@react-hookz/web`**
 *
 * Tracks the result and errors of the provided async function and provides
 * handles to control its execution.
 *
 * Skips executions when an active promise is already in place.
 *
 * @param asyncFn Function that returns a promise.
 * @param initialValue Value that will be set on initialisation before the async
 * function is executed.
 */
export declare function useThrottledAsync<Result, Args extends unknown[] = unknown[]>(asyncFn: (...params: Args) => Promise<Result>, initialValue: Result): [
    AsyncState<Result>,
    UseAsyncActions<Result, Args>,
    UseAsyncMeta<Result, Args>
];
export declare function useThrottledAsync<Result, Args extends unknown[] = unknown[]>(asyncFn: (...params: Args) => Promise<Result>, initialValue?: Result): [
    AsyncState<Result | undefined>,
    UseAsyncActions<Result, Args>,
    UseAsyncMeta<Result, Args>
];
