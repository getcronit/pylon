'use strict';

var __typeError = (msg) => {
  throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _lastAdded;
class ModifiedSet extends Set {
  constructor() {
    super(...arguments);
    __privateAdd(this, _lastAdded);
  }
  add(value) {
    if (!super.has(value)) {
      __privateSet(this, _lastAdded, value);
    }
    return super.add(value);
  }
  clear() {
    __privateSet(this, _lastAdded, void 0);
    return super.clear();
  }
  /**
   * Only changes when the last call to `.add()` is a new value had not been
   * added yet.
   */
  get lastAdded() {
    return __privateGet(this, _lastAdded);
  }
}
_lastAdded = new WeakMap();

module.exports = ModifiedSet;
