import { GQtyError, type BaseGeneratedSchema, type GQtyClient, type RetryOptions } from 'gqty';
import type { OnErrorHandler } from '../common';
import type { ReactClientOptionsWithDefaults } from '../utils';
export interface UseMutationOptions<TData> {
    onComplete?: (data: TData) => Promise<void> | void;
    /** @deprecated Use onComplete instead. */
    onCompleted?: (data: TData) => void;
    onError?: OnErrorHandler;
    operationName?: string;
    /**
     * Retry behaviour
     *
     * @default false
     */
    retry?: RetryOptions;
    /**
     * Refetch specific queries after mutation completion.
     *
     * You can give functions or parts of the schema to be refetched
     *
     * @deprecated
     */
    refetchQueries?: unknown[];
    /**
     * Await refetch resolutions before calling the mutation actually complete
     *
     * @deprecated
     */
    awaitRefetchQueries?: boolean;
    /** Skip the cache update after a successful fetch. */
    noCache?: boolean;
    /**
     * Activate special handling of non-serializable variables,
     * for example, files uploading
     *
     * @default false
     * @deprecated
     */
    nonSerializableVariables?: boolean;
    /**
     * Enable suspense behavior
     */
    suspense?: boolean;
    /**
     * extension object that allows user to pass custom data to the query fetcher.
     */
    extensions?: Record<string, unknown>;
}
export type UseMutationState = {
    error?: GQtyError;
    isLoading: boolean;
};
export interface UseMutation<TSchema extends BaseGeneratedSchema> {
    <TData, TArgs = never>(fn: (mutation: NonNullable<TSchema['mutation']>, args: TArgs) => TData, options?: UseMutationOptions<TData>): readonly [
        (options?: {
            fn?: typeof fn;
            args: TArgs;
        }) => Promise<TData>,
        UseMutationState & {
            data?: TData;
        }
    ];
}
export declare const createUseMutation: <TSchema extends BaseGeneratedSchema>({ resolve, refetch }: GQtyClient<TSchema>, { defaults: { mutationSuspense: defaultSuspense, retry: defaultRetry }, }: ReactClientOptionsWithDefaults) => UseMutation<TSchema>;
