'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const gqty = require('gqty');
const React = require('react');

const createUseMutation = ({ resolve, refetch }, {
  defaults: { mutationSuspense: defaultSuspense, retry: defaultRetry }
}) => {
  const useMutation = (mutationFn, {
    onCompleted,
    onComplete = onCompleted,
    onError,
    retry = defaultRetry,
    refetchQueries = [],
    awaitRefetchQueries,
    suspense = defaultSuspense,
    noCache = false,
    extensions
  } = {}) => {
    const [state, setState] = React.useState({});
    if (suspense) {
      if (state.promise) throw state.promise;
      if (state.error) throw state.error;
    }
    const mutate = React.useCallback(
      async ({
        fn = mutationFn,
        args
      } = {}) => {
        if (!fn) {
          throw new gqty.GQtyError(`Please specify a mutation function.`);
        }
        try {
          const promise = resolve(
            ({ mutation }) => {
              if (mutation === void 0) {
                throw new gqty.GQtyError(`Mutation is not defined in the schema.`);
              }
              return fn(mutation, args);
            },
            {
              cachePolicy: noCache ? "no-store" : "no-cache",
              retryPolicy: retry,
              extensions
            }
          ).then((data2) => {
            const refetches = refetchQueries.map((v) => refetch(v));
            return awaitRefetchQueries ? Promise.all(refetches).then(() => data2) : data2;
          });
          setState({ promise });
          const data = await promise;
          await (onComplete == null ? void 0 : onComplete(data));
          setState({ data });
          return data;
        } catch (e) {
          const error = gqty.GQtyError.create(e);
          onError == null ? void 0 : onError(error);
          setState({ error });
          throw error;
        }
      },
      [mutationFn, noCache, retry, refetchQueries, awaitRefetchQueries]
    );
    return Object.freeze([
      mutate,
      Object.freeze({
        data: state.data,
        error: state.error,
        isLoading: state.promise !== void 0
      })
    ]);
  };
  return useMutation;
};

exports.createUseMutation = createUseMutation;
