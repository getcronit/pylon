/** A Set that tracks the last added value. */
export default class ModifiedSet<T> extends Set<T> {
    #private;
    add(value: T): this;
    clear(): void;
    /**
     * Only changes when the last call to `.add()` is a new value had not been
     * added yet.
     */
    get lastAdded(): T | undefined;
}
