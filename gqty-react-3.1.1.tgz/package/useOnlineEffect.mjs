import { useEffect } from 'react';

const useOnlineEffect = (fn, deps) => {
  useEffect(() => {
    var _a;
    (_a = globalThis.addEventListener) == null ? void 0 : _a.call(globalThis, "online", fn);
    return () => {
      var _a2;
      (_a2 = globalThis.removeEventListener) == null ? void 0 : _a2.call(globalThis, "online", fn);
    };
  }, deps);
};

export { useOnlineEffect };
