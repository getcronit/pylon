'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const React = require('react');

const useOnlineEffect = (fn, deps) => {
  React.useEffect(() => {
    var _a;
    (_a = globalThis.addEventListener) == null ? void 0 : _a.call(globalThis, "online", fn);
    return () => {
      var _a2;
      (_a2 = globalThis.removeEventListener) == null ? void 0 : _a2.call(globalThis, "online", fn);
    };
  }, deps);
};

exports.useOnlineEffect = useOnlineEffect;
