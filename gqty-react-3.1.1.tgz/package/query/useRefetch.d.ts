import { GQtyError, type BaseGeneratedSchema, type GQtyClient, type RetryOptions } from 'gqty';
import { type ReactClientOptionsWithDefaults } from '../utils';
interface UseRefetchState {
    isLoading: boolean;
    error?: GQtyError;
    startWatching: () => void;
    stopWatching: () => void;
}
export interface UseRefetchOptions {
    notifyOnNetworkStatusChange?: boolean;
    operationName?: string;
    retry?: RetryOptions;
    startWatching?: boolean;
    suspense?: boolean;
}
export interface UseRefetch<TSchema extends BaseGeneratedSchema> {
    (refetchOptions?: UseRefetchOptions): (<T = void>(refetchArg?: T | ((query: TSchema['query']) => T)) => Promise<T | undefined>) & UseRefetchState;
}
export declare const createUseRefetch: <TSchema extends BaseGeneratedSchema>(client: GQtyClient<TSchema>, { defaults: { retry: defaultRetry } }: ReactClientOptionsWithDefaults) => UseRefetch<TSchema>;
export {};
