import { GQtyError, type BaseGeneratedSchema, type GQtyClient, type RetryOptions } from 'gqty';
import { type LegacyFetchPolicy, type OnErrorHandler } from '../common';
import type { ReactClientOptionsWithDefaults } from '../utils';
export type LazyFetchPolicy = Exclude<LegacyFetchPolicy, 'cache-first'>;
export interface UseLazyQueryOptions<TData> {
    onCompleted?: (data: TData) => void;
    onError?: OnErrorHandler;
    fetchPolicy?: LazyFetchPolicy;
    retry?: RetryOptions;
    suspense?: boolean;
    operationName?: string;
}
export interface UseLazyQueryState<TData> {
    data: TData | undefined;
    error?: GQtyError;
    isLoading: boolean;
    isCalled: boolean;
    promise?: Promise<TData>;
}
export interface UseLazyQuery<GeneratedSchema extends BaseGeneratedSchema> {
    <TData = unknown, TArgs = undefined>(fn: (query: GeneratedSchema['query'], args: TArgs) => TData, options?: UseLazyQueryOptions<TData>): readonly [
        (...opts: undefined extends TArgs ? [
            {
                fn?: (query: GeneratedSchema['query'], args: TArgs) => TData;
                args?: TArgs;
                fetchPolicy?: LazyFetchPolicy;
                operationName?: string;
            }?
        ] : [
            {
                fn?: (query: GeneratedSchema['query'], args: TArgs) => TData;
                args: TArgs;
                fetchPolicy?: LazyFetchPolicy;
                opertionName?: string;
            }
        ]) => Promise<TData>,
        UseLazyQueryState<TData>
    ];
}
export declare function createUseLazyQuery<TSchema extends BaseGeneratedSchema>({ resolve }: GQtyClient<TSchema>, { defaults: { retry: defaultRetry, lazyQuerySuspense: defaultSuspense, lazyFetchPolicy: defaultFetchPolicy, }, }: ReactClientOptionsWithDefaults): UseLazyQuery<TSchema>;
