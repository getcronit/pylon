import { type BaseGeneratedSchema, type GQtyError, type RetryOptions } from 'gqty';
import { type LegacyFetchPolicy, type OnErrorHandler } from '../common';
import type { ReactClientOptionsWithDefaults } from '../utils';
import type { UseQuery } from './useQuery';
export interface UseTransactionQueryState<TData> {
    data?: TData;
    error?: GQtyError;
    isLoading: boolean;
    isCalled: boolean;
}
export type UseTransactionQueryOptions<TData, TVariables> = {
    cachePolicy?: RequestCache;
    fetchPolicy?: LegacyFetchPolicy;
    skip?: boolean;
    /**
     * Frequency in milliseconds of polling/refetch of the query
     */
    pollInterval?: number;
    /**
     * If it should do polling while on background
     *
     * @default false
     */
    pollInBackground?: boolean;
    notifyOnNetworkStatusChange?: boolean;
    variables?: TVariables;
    onCompleted?: (data: TData) => void;
    onError?: OnErrorHandler;
    retry?: RetryOptions;
    suspense?: boolean;
    operationName?: string;
};
export interface UseTransactionQuery<TSchema extends BaseGeneratedSchema> {
    <TData, TVariables = undefined>(fn: (query: TSchema['query'], variables?: TVariables) => TData, options?: UseTransactionQueryOptions<TData, TVariables>): UseTransactionQueryState<TData>;
}
export declare function createUseTransactionQuery<TSchema extends BaseGeneratedSchema>(useQuery: UseQuery<TSchema>, { defaults: { transactionFetchPolicy: defaultFetchPolicy, retry: defaultRetry, transactionQuerySuspense: defaultSuspense, }, }: ReactClientOptionsWithDefaults): UseTransactionQuery<TSchema>;
