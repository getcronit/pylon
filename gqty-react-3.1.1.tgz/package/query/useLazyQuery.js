'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const gqty = require('gqty');
const React = require('react');
const common = require('../common.js');

function UseLazyQueryReducer(state, action) {
  switch (action.type) {
    case "loading": {
      if (state.isLoading) return state;
      return {
        data: state.data,
        isLoading: true,
        isCalled: true,
        promise: action.promise
      };
    }
    case "success": {
      return {
        data: action.data,
        isLoading: false,
        isCalled: true
      };
    }
    case "failure": {
      return {
        data: state.data,
        isLoading: false,
        error: action.error,
        isCalled: true
      };
    }
    case "cache-found": {
      return {
        data: action.data,
        isLoading: state.isLoading,
        isCalled: true
      };
    }
  }
}
function InitUseLazyQueryReducer() {
  return {
    data: void 0,
    isLoading: false,
    isCalled: false
  };
}
function createUseLazyQuery({ resolve }, {
  defaults: {
    retry: defaultRetry,
    lazyQuerySuspense: defaultSuspense,
    lazyFetchPolicy: defaultFetchPolicy
  }
}) {
  const useLazyQuery = (fn, {
    onCompleted,
    onError,
    fetchPolicy: hookDefaultFetchPolicy = defaultFetchPolicy,
    retry = defaultRetry,
    suspense = defaultSuspense,
    operationName: defaultOperationName
  } = {}) => {
    const [state, dispatch] = React.useReducer(
      UseLazyQueryReducer,
      void 0,
      InitUseLazyQueryReducer
    );
    if (suspense) {
      if (state.promise) throw state.promise;
      if (state.error) throw state.error;
    }
    return React.useMemo(() => {
      const fetchQuery = async ({
        fn: resolveFn = fn,
        args,
        fetchPolicy = hookDefaultFetchPolicy,
        operationName = defaultOperationName
      } = {}) => {
        let innerFetchPromise;
        try {
          const fetchPromise = resolve(
            ({ query }) => resolveFn(query, args),
            {
              awaitsFetch: false,
              cachePolicy: common.translateFetchPolicy(fetchPolicy),
              onFetch(promise) {
                innerFetchPromise = promise;
              },
              retryPolicy: retry,
              operationName
            }
          ).then((data2) => {
            const typedData = data2;
            if (fetchPolicy === "cache-and-network") {
              dispatch({ type: "cache-found", data: typedData });
            }
            return innerFetchPromise != null ? innerFetchPromise : typedData;
          });
          dispatch({ type: "loading", promise: fetchPromise });
          const data = await fetchPromise;
          onCompleted == null ? void 0 : onCompleted(data);
          dispatch({ type: "success", data });
          return data;
        } catch (error) {
          const typedError = gqty.GQtyError.create(error);
          onError == null ? void 0 : onError(typedError);
          dispatch({ type: "failure", error: typedError });
          throw error;
        }
      };
      return Object.freeze([fetchQuery, state]);
    }, [fn, onCompleted, onError, retry]);
  };
  return useLazyQuery;
}

exports.createUseLazyQuery = createUseLazyQuery;
