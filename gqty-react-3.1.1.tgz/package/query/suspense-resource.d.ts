export interface SuspenseResourceCache<Key, Value> {
    get(key: Key): Value | undefined;
    set(key: Key, value: Value): void;
    has(key: Key): boolean;
    clear(): void;
    delete(key: Key): boolean;
}
export interface SuspenseResource<TResult> {
    read(): TResult;
}
export declare function createSuspenseResourceCache<Key, Value>(): SuspenseResourceCache<Key, Value>;
export declare function createSuspenseResource<TResult>(asyncFn: () => Promise<TResult>): SuspenseResource<TResult>;
export declare function getSuspenseResource<Key, TResult>(cache: SuspenseResourceCache<Key, SuspenseResource<TResult>>, key: Key, asyncFn: () => Promise<TResult>): SuspenseResource<TResult>;
