import { useUpdateEffect } from '@react-hookz/web';
import { useEffect } from 'react';
import { translateFetchPolicy } from '../common.mjs';

function createUseTransactionQuery(useQuery, {
  defaults: {
    transactionFetchPolicy: defaultFetchPolicy,
    retry: defaultRetry,
    transactionQuerySuspense: defaultSuspense
  }
}) {
  const useTransactionQuery = (fn, {
    fetchPolicy = defaultFetchPolicy,
    cachePolicy = translateFetchPolicy(fetchPolicy),
    notifyOnNetworkStatusChange = true,
    onCompleted,
    onError,
    operationName,
    pollInBackground = false,
    pollInterval,
    retry = defaultRetry,
    skip = false,
    suspense = defaultSuspense,
    variables
  } = {}) => {
    const query = useQuery({
      cachePolicy,
      fetchInBackground: pollInBackground,
      notifyOnNetworkStatusChange,
      operationName,
      prepare: ({ query: query2 }) => skip ? void 0 : fn(query2, variables),
      refetchInterval: pollInterval,
      refetchOnReconnect: false,
      refetchOnRender: false,
      refetchOnWindowVisible: false,
      retry,
      suspense
    });
    useUpdateEffect(() => {
      const {
        $state: { isLoading, error }
      } = query;
      if (!isLoading && !error) {
        onCompleted == null ? void 0 : onCompleted(fn(query, variables));
      }
    }, [query.$state.isLoading]);
    useUpdateEffect(() => {
      if (query.$state.error) {
        onError == null ? void 0 : onError(query.$state.error);
      }
    }, [query.$state.error]);
    useEffect(() => {
      if (!skip) {
        query.$refetch(false);
      }
    }, [skip]);
    return skip ? {
      isCalled: false,
      isLoading: false
    } : {
      data: fn(query, variables),
      isCalled: true,
      isLoading: query.$state.isLoading,
      error: query.$state.error
    };
  };
  return useTransactionQuery;
}

export { createUseTransactionQuery };
