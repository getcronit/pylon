'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const gqty = require('gqty');
const index_js = require('use-sync-external-store/shim/index.js');
const memoryStore = require('../memoryStore.js');

function createPrepareQuery({ prefetch, query, refetch: clientRefetch }, {
  defaults: { preparedSuspense: defaultSuspense }
}) {
  const prepareQuery = (fn) => {
    const store = memoryStore.createMemoryStore({
      called: false,
      isLoading: false,
      isRefetching: false
    });
    const preload = async (args) => {
      store.set({
        data: void 0,
        error: void 0,
        promise: void 0,
        called: true,
        isLoading: true,
        isRefetching: false
      });
      const promise = prefetch((query2) => fn(query2, args));
      if (promise instanceof Promise) {
        store.add({ promise });
      }
      try {
        const data = await promise;
        store.add({
          data,
          promise: void 0,
          isLoading: false
        });
        return data;
      } catch (error) {
        store.add({
          error: gqty.GQtyError.create(error),
          promise: void 0,
          isLoading: false
        });
        throw error;
      }
    };
    const refetch = async (args) => {
      store.set({
        data: void 0,
        error: void 0,
        promise: void 0,
        called: true,
        isLoading: false,
        isRefetching: true
      });
      const promise = clientRefetch(() => fn(query, args));
      store.add({ promise });
      try {
        const data = await promise;
        store.add({
          data,
          promise: void 0,
          isRefetching: false
        });
        return data;
      } catch (error) {
        store.add({
          error: gqty.GQtyError.create(error),
          promise: void 0,
          isRefetching: false
        });
        throw error;
      }
    };
    const usePrepared = ({
      suspense = defaultSuspense
    } = {}) => {
      const state = index_js.useSyncExternalStore(store.subscribe, store.get);
      if (suspense) {
        if (state.promise) throw state.promise;
        if (state.error) throw state.error;
      }
      return state;
    };
    return {
      preload,
      refetch,
      usePrepared,
      callback: fn
    };
  };
  return prepareQuery;
}

exports.createPrepareQuery = createPrepareQuery;
