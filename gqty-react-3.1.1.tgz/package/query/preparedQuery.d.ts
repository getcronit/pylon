import { GQtyError, type BaseGeneratedSchema, type GQtyClient } from 'gqty';
import type { ReactClientOptionsWithDefaults } from '../utils';
export interface UsePreparedQueryOptions {
    suspense?: boolean;
}
export type TQueryFunction<TSchema extends BaseGeneratedSchema, TArgs = Record<string, unknown> | undefined, TData = unknown> = (query: TSchema['query'], args: TArgs) => TData;
export interface PreparedQuery<TSchema extends BaseGeneratedSchema, TFunction extends TQueryFunction<TSchema>> {
    preload: PreloadFn<TSchema, TFunction>;
    refetch: RefetchFn<TSchema, TFunction>;
    usePrepared: UsePreparedHook<TSchema, TFunction>;
    callback: TFunction;
}
export type PreloadFn<TSchema extends BaseGeneratedSchema, TFunction extends TQueryFunction<TSchema>> = (args?: Parameters<TFunction>[1]) => Promise<ReturnType<TFunction>>;
export type RefetchFn<TSchema extends BaseGeneratedSchema, TFunction extends TQueryFunction<TSchema>> = (args?: Parameters<TFunction>[1]) => Promise<ReturnType<TFunction>>;
export type UsePreparedHook<TSchema extends BaseGeneratedSchema, TFunction extends TQueryFunction<TSchema>> = (options?: UsePreparedQueryOptions) => PreparedQueryState<ReturnType<TFunction>>;
export type PreparedQueryState<TData = unknown> = {
    data?: TData;
    error?: GQtyError;
    promise?: Promise<TData>;
    isLoading: boolean;
    isRefetching: boolean;
    called: boolean;
};
export interface PrepareQuery<TSchema extends BaseGeneratedSchema> {
    <TFunction extends TQueryFunction<TSchema>>(fn: TFunction): PreparedQuery<TSchema, TFunction>;
}
export declare function createPrepareQuery<TSchema extends BaseGeneratedSchema>({ prefetch, query, refetch: clientRefetch }: GQtyClient<TSchema>, { defaults: { preparedSuspense: defaultSuspense }, }: ReactClientOptionsWithDefaults): PrepareQuery<TSchema>;
