import type { BaseGeneratedSchema, GQtyClient } from 'gqty';
import * as React from 'react';
import type { OnErrorHandler } from '../common';
import type { ReactClientOptionsWithDefaults } from '../utils';
export interface GraphQLHOCOptions {
    onError?: OnErrorHandler;
    operationName?: string;
    staleWhileRevalidate?: boolean;
    suspense?: boolean | {
        fallback: React.SuspenseProps['fallback'];
    };
}
export interface GraphQLHOC {
    <P>(component: (props: P) => React.ReactElement | null, options?: GraphQLHOCOptions): (props: P) => React.ReactElement | null;
}
export declare function createGraphqlHOC<TSchema extends BaseGeneratedSchema>({ createResolver, subscribeLegacySelections }: GQtyClient<TSchema>, { defaults: { suspense: defaultSuspense, retry }, }: ReactClientOptionsWithDefaults): GraphQLHOC;
