'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const web = require('@react-hookz/web');
const React = require('react');
const common = require('../common.js');

function createUseTransactionQuery(useQuery, {
  defaults: {
    transactionFetchPolicy: defaultFetchPolicy,
    retry: defaultRetry,
    transactionQuerySuspense: defaultSuspense
  }
}) {
  const useTransactionQuery = (fn, {
    fetchPolicy = defaultFetchPolicy,
    cachePolicy = common.translateFetchPolicy(fetchPolicy),
    notifyOnNetworkStatusChange = true,
    onCompleted,
    onError,
    operationName,
    pollInBackground = false,
    pollInterval,
    retry = defaultRetry,
    skip = false,
    suspense = defaultSuspense,
    variables
  } = {}) => {
    const query = useQuery({
      cachePolicy,
      fetchInBackground: pollInBackground,
      notifyOnNetworkStatusChange,
      operationName,
      prepare: ({ query: query2 }) => skip ? void 0 : fn(query2, variables),
      refetchInterval: pollInterval,
      refetchOnReconnect: false,
      refetchOnRender: false,
      refetchOnWindowVisible: false,
      retry,
      suspense
    });
    web.useUpdateEffect(() => {
      const {
        $state: { isLoading, error }
      } = query;
      if (!isLoading && !error) {
        onCompleted == null ? void 0 : onCompleted(fn(query, variables));
      }
    }, [query.$state.isLoading]);
    web.useUpdateEffect(() => {
      if (query.$state.error) {
        onError == null ? void 0 : onError(query.$state.error);
      }
    }, [query.$state.error]);
    React.useEffect(() => {
      if (!skip) {
        query.$refetch(false);
      }
    }, [skip]);
    return skip ? {
      isCalled: false,
      isLoading: false
    } : {
      data: fn(query, variables),
      isCalled: true,
      isLoading: query.$state.isLoading,
      error: query.$state.error
    };
  };
  return useTransactionQuery;
}

exports.createUseTransactionQuery = createUseTransactionQuery;
