function createSuspenseResourceCache() {
  const map = /* @__PURE__ */ new Map();
  return {
    get(key) {
      return map.get(key);
    },
    set(key, value) {
      map.set(key, value);
    },
    has(key) {
      return map.has(key);
    },
    clear() {
      map.clear();
    },
    delete(key) {
      return map.delete(key);
    }
  };
}
function createSuspenseResource(asyncFn) {
  let status = "pending";
  let result;
  const suspender = asyncFn().then(
    (data) => {
      status = "success";
      result = data;
    },
    (err) => {
      status = "error";
      result = err instanceof Error ? err : new Error(String(err));
    }
  );
  return {
    read() {
      if (status === "pending") {
        throw suspender;
      }
      if (status === "error") {
        throw result;
      }
      return result;
    }
  };
}
function getSuspenseResource(cache, key, asyncFn) {
  if (cache.has(key)) {
    return cache.get(key);
  }
  const resource = createSuspenseResource(asyncFn);
  cache.set(key, resource);
  return resource;
}

export { createSuspenseResource, createSuspenseResourceCache, getSuspenseResource };
