import { type BaseGeneratedSchema, type GQtyClient, type RetryOptions } from 'gqty';
import { coreHelpers, sortBy, uniqBy, type LegacyFetchPolicy } from '../common';
import type { ReactClientOptionsWithDefaults } from '../utils';
export type PaginatedQueryFetchPolicy = Extract<LegacyFetchPolicy, 'cache-first' | 'cache-and-network' | 'network-only'>;
export interface UsePaginatedQueryMergeParams<TData> {
    data: {
        existing: TData | undefined;
        incoming: TData;
    };
    uniqBy: typeof uniqBy;
    sortBy: typeof sortBy;
}
export interface UsePaginatedQueryOptions<TData, TArgs> {
    /**
     * Initial arguments used on first request
     */
    initialArgs: TArgs;
    /**
     * Custom merge function
     */
    merge?: (params: UsePaginatedQueryMergeParams<TData>) => TData | undefined | void;
    /**
     * Fetch Policy behavior
     *
     * If using `cache-and-network` and `merge`, we recomend using the `uniqBy`
     * helper included inside the `merge` parameters.
     */
    fetchPolicy?: PaginatedQueryFetchPolicy;
    operationName?: string;
    retry?: RetryOptions;
    /**
     * Skip initial query call
     *
     * @default false
     */
    skip?: boolean;
    /**
     * Activate suspense on first call
     */
    suspense?: boolean;
}
export interface UsePaginatedQueryData<TData, TArgs> {
    /**
     * Query Data
     */
    data: TData | undefined;
    /**
     * Current arguments used in the query
     */
    args: TArgs;
    /**
     * Network fetch is loading
     */
    isLoading: boolean;
    /**
     * Main function to be used
     *
     * If new args are not specified, the previous or initial args are used
     *
     * In the second parameter you can override the `"fetchPolicy"`, for example
     * you can set it to `"network-only"` to do a refetch.
     */
    fetchMore: (
    /**
     * Optional new args. It can receive a function that receives the previous
     * data/args and returns the new args, or the new args directly
     *
     * If not specified or `undefined`, the previous or initial args are used.
     */
    newArgs?: ((data: FetchMoreCallbackArgs<TData, TArgs>) => TArgs) | TArgs | undefined, 
    /**
     * Override hook fetchPolicy
     */
    fetchPolicy?: PaginatedQueryFetchPolicy) => Promise<TData> | TData;
}
export interface FetchMoreCallbackArgs<TData, TArgs> {
    existingData: TData | undefined;
    existingArgs: TArgs;
}
export interface UsePaginatedQuery<TSchema extends BaseGeneratedSchema> {
    <TData, TArgs extends Record<string, unknown> | string | number | null>(fn: (query: TSchema['query'], args: TArgs, helpers: typeof coreHelpers) => TData, options: UsePaginatedQueryOptions<TData, TArgs>): UsePaginatedQueryData<TData, TArgs>;
}
export declare const createUsePaginatedQuery: <TSchema extends BaseGeneratedSchema>({ createResolver, resolve }: GQtyClient<TSchema>, { defaults: { paginatedQueryFetchPolicy: defaultFetchPolicy, paginatedQuerySuspense: defaultSuspense, }, }: ReactClientOptionsWithDefaults) => UsePaginatedQuery<TSchema>;
