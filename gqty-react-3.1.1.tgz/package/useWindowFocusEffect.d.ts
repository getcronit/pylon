import { type DependencyList } from 'react';
export type UseFocusChangeEffectOptions = {
    enabled?: boolean;
};
export declare const useWindowFocusEffect: (fn: (...args: unknown[]) => unknown, deps?: DependencyList) => void;
