'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const React = require('react');
const server = require('react-dom/server');
const utils = require('../utils.js');

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  const n = Object.create(null);
  if (e) {
    for (const k in e) {
      if (k !== 'default') {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    }
  }
  n["default"] = e;
  return Object.freeze(n);
}

const IS_SERVER = typeof window === "undefined";
function createSSRHelpers({ hydrateCache, prepareRender, query, refetch }, { defaults: { refetchAfterHydrate } }) {
  const prepareReactRender = async function prepareReactRender2(element) {
    const majorVersion = +server.version.split(".")[0];
    if (majorVersion >= 18) {
      const { renderToPipeableStream, renderToReadableStream } = await Promise.resolve().then(function () { return /*#__PURE__*/_interopNamespace(require('react-dom/server')); });
      if (renderToReadableStream !== void 0) {
        return prepareRender(async () => {
          const stream = await renderToReadableStream(element);
          await stream.allReady;
        });
      } else {
        return prepareRender(
          () => new Promise((resolve, reject) => {
            renderToPipeableStream(element, {
              onAllReady: resolve,
              onError: reject
            });
          })
        );
      }
    } else {
      const ssrPrepass = utils.getDefault(await Promise.resolve().then(function () { return require('react-ssr-prepass'); }));
      return prepareRender(() => ssrPrepass(element));
    }
  };
  const useHydrateCache = function useHydrateCache2({
    cacheSnapshot,
    shouldRefetch = refetchAfterHydrate
  }) {
    React.useMemo(() => {
      if (!IS_SERVER && cacheSnapshot) {
        hydrateCache({ cacheSnapshot, shouldRefetch: false });
      }
    }, [cacheSnapshot]);
    React.useEffect(() => {
      if (!IS_SERVER && shouldRefetch) {
        refetch(query).catch(console.error);
      }
    }, [shouldRefetch]);
  };
  return {
    useHydrateCache,
    prepareReactRender
  };
}

exports.createSSRHelpers = createSSRHelpers;
