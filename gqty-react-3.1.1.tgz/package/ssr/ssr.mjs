import { useMemo, useEffect } from 'react';
import { version } from 'react-dom/server';
import { getDefault } from '../utils.mjs';

const IS_SERVER = typeof window === "undefined";
function createSSRHelpers({ hydrateCache, prepareRender, query, refetch }, { defaults: { refetchAfterHydrate } }) {
  const prepareReactRender = async function prepareReactRender2(element) {
    const majorVersion = +version.split(".")[0];
    if (majorVersion >= 18) {
      const { renderToPipeableStream, renderToReadableStream } = await import('react-dom/server');
      if (renderToReadableStream !== void 0) {
        return prepareRender(async () => {
          const stream = await renderToReadableStream(element);
          await stream.allReady;
        });
      } else {
        return prepareRender(
          () => new Promise((resolve, reject) => {
            renderToPipeableStream(element, {
              onAllReady: resolve,
              onError: reject
            });
          })
        );
      }
    } else {
      const ssrPrepass = getDefault(await import('react-ssr-prepass'));
      return prepareRender(() => ssrPrepass(element));
    }
  };
  const useHydrateCache = function useHydrateCache2({
    cacheSnapshot,
    shouldRefetch = refetchAfterHydrate
  }) {
    useMemo(() => {
      if (!IS_SERVER && cacheSnapshot) {
        hydrateCache({ cacheSnapshot, shouldRefetch: false });
      }
    }, [cacheSnapshot]);
    useEffect(() => {
      if (!IS_SERVER && shouldRefetch) {
        refetch(query).catch(console.error);
      }
    }, [shouldRefetch]);
  };
  return {
    useHydrateCache,
    prepareReactRender
  };
}

export { createSSRHelpers };
