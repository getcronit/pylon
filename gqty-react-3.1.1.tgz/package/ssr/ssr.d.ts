import { type BaseGeneratedSchema, type GQtyClient, type LegacyHydrateCacheOptions } from 'gqty';
import { type ReactNode } from 'react';
import { type ReactClientOptionsWithDefaults } from '../utils';
export interface UseHydrateCacheOptions extends Partial<LegacyHydrateCacheOptions> {
    /**
     * Cache snapshot, returned from `prepareReactRender`
     */
    cacheSnapshot: string | undefined;
    /**
     * If it should refetch everything after the component is mounted
     *
     * @default
     * false
     */
    shouldRefetch?: boolean;
}
/**
 * Props with `cacheSnapshot` that would be returned from `prepareReactRender`
 */
export type PropsWithServerCache<T extends Record<string | number, unknown> = Record<string | number, unknown>> = {
    /**
     * Cache snapshot, returned from `prepareReactRender`
     */
    cacheSnapshot?: string;
} & T;
export interface UseHydrateCache {
    ({ cacheSnapshot, shouldRefetch }: UseHydrateCacheOptions): void;
}
export interface PrepareReactRender {
    (element: ReactNode): Promise<{
        cacheSnapshot: string;
    }>;
}
export declare function createSSRHelpers<TSchema extends BaseGeneratedSchema>({ hydrateCache, prepareRender, query, refetch }: GQtyClient<TSchema>, { defaults: { refetchAfterHydrate } }: ReactClientOptionsWithDefaults): {
    useHydrateCache: UseHydrateCache;
    prepareReactRender: PrepareReactRender;
};
