import { type BaseGeneratedSchema, type GQtyClient, type RetryOptions } from 'gqty';
import type { LegacyFetchPolicy } from './common';
import { type UseMetaState } from './meta/useMetaState';
import { type UseMutation } from './mutation/useMutation';
import { type GraphQLHOC } from './query/hoc';
import { type PrepareQuery } from './query/preparedQuery';
import { type LazyFetchPolicy, type UseLazyQuery } from './query/useLazyQuery';
import { type PaginatedQueryFetchPolicy, type UsePaginatedQuery } from './query/usePaginatedQuery';
import { type UseQuery } from './query/useQuery';
import { type UseRefetch } from './query/useRefetch';
import { type UseTransactionQuery } from './query/useTransactionQuery';
import { type PrepareReactRender, type UseHydrateCache } from './ssr/ssr';
import { type UseSubscription } from './subscription/useSubscription';
export interface ReactClientDefaults {
    /**
     * The value of $state.isLoading before the first fetch happens, useful
     * for skipping SSR and hydrations.
     */
    initialLoadingState?: boolean;
    /**
     * Enable/Disable by default 'React Suspense' behavior
     *
     * > _Valid for __graphql HOC__ & __useQuery___
     *
     * > _You can override it on a per-function basis_
     *
     * @default false
     */
    suspense?: boolean;
    /**
     * Enable/Disable by default 'React Suspense' behavior for useLazyQuery hook
     *
     * > _Valid only for __useLazyQuery___
     *
     * > _You can override it on a per-hook basis_
     *
     * @default false
     */
    lazyQuerySuspense?: boolean;
    /**
     * Enable/Disable by default 'React Suspense' behavior for useTransactionQuery hook
     *
     * > _Valid only for __useTransactionQuery___
     *
     * > _You can override it on a per-hook basis_
     *
     * __The _default value_ is obtained from the "`defaults.suspense`" value__
     */
    transactionQuerySuspense?: boolean;
    /**
     * Enable/Disable by default 'React Suspense' behavior for useMutation hook
     *
     * > _Valid only for __useMutation___
     *
     * > _You can override it on a per-hook basis_
     *
     * @default false
     */
    mutationSuspense?: boolean;
    /**
     * Enable/Disable by default 'React Suspense' behavior for prepareQuery hooks
     *
     * > _Valid only for __prepareQuery___ hooks
     *
     * > _You can override it on a per-hook basis_
     *
     * __The _default value_ is obtained from the "`defaults.suspense`" value__
     */
    preparedSuspense?: boolean;
    /**
     * Enable/Disable by default 'React Suspense' behavior for usePaginatedQuery hooks
     *
     * > _Valid only for __usePaginatedQuery___ hooks
     *
     * > _You can override it on a per-hook basis_
     *
     * @default false
     */
    paginatedQuerySuspense?: boolean;
    /**
     * Define default 'fetchPolicy' hooks behaviour
     *
     * > _Valid for __useTransactionQuery___
     *
     * > _You can override it on a per-hook basis_
     *
     * @default "cache-first"
     */
    transactionFetchPolicy?: LegacyFetchPolicy;
    /**
     * Define default 'fetchPolicy' hooks behaviour
     *
     * > Valid for __useLazyQuery__
     *
     * > _You can override it on a per-hook basis_
     *
     * @default "network-only"
     */
    lazyFetchPolicy?: LazyFetchPolicy;
    /**
     * Define default 'fetchPolicy' hooks behaviour
     *
     * > __Valid for __usePaginatedQuery____
     *
     * > _You can override it on a per-hook basis_
     *
     * @default "cache-first"
     */
    paginatedQueryFetchPolicy?: PaginatedQueryFetchPolicy;
    /**
     * __Enable__/__Disable__ default 'stale-while-revalidate' behaviour
     *
     * > _Valid for __graphql HOC__ & __useQuery___
     *
     * > _You can override it on a per-function basis_
     *
     * @default false
     */
    staleWhileRevalidate?: boolean;
    /**
     * Retry strategy upon fetch failures.
     *
     * @default true
     */
    retry?: RetryOptions;
    /**
     * Refetch after SSR hydration
     *
     * @default false
     */
    refetchAfterHydrate?: boolean;
}
export interface CreateReactClientOptions {
    /**
     * Default behaviour values
     */
    defaults?: ReactClientDefaults;
}
export interface ReactClient<TSchema extends BaseGeneratedSchema> {
    useQuery: UseQuery<TSchema>;
    useRefetch: UseRefetch<TSchema>;
    useLazyQuery: UseLazyQuery<TSchema>;
    useTransactionQuery: UseTransactionQuery<TSchema>;
    usePaginatedQuery: UsePaginatedQuery<TSchema>;
    useMutation: UseMutation<TSchema>;
    graphql: GraphQLHOC;
    state: {
        isLoading: boolean;
    };
    prepareReactRender: PrepareReactRender;
    useHydrateCache: UseHydrateCache;
    useMetaState: UseMetaState;
    useSubscription: UseSubscription<TSchema>;
    prepareQuery: PrepareQuery<TSchema>;
}
export declare function createReactClient<TSchema extends BaseGeneratedSchema>(client: GQtyClient<TSchema>, { defaults: { suspense }, defaults: { initialLoadingState, transactionFetchPolicy, lazyFetchPolicy, staleWhileRevalidate, retry, lazyQuerySuspense, transactionQuerySuspense, mutationSuspense, preparedSuspense, refetchAfterHydrate, paginatedQueryFetchPolicy, paginatedQuerySuspense, }, ...options }?: CreateReactClientOptions): ReactClient<TSchema>;
