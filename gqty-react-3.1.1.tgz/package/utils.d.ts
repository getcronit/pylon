import type { CreateReactClientOptions, ReactClientDefaults } from './client';
export declare function areArraysEqual(a: unknown[] | null | undefined, b: unknown[] | null | undefined): boolean;
export type ReactClientOptionsWithDefaults = Omit<CreateReactClientOptions, 'defaults'> & {
    defaults: Required<ReactClientDefaults>;
};
export declare function getDefault<T extends Record<string, any>>(v: T | {
    default: T;
}): T;
