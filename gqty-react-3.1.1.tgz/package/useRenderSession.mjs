import { useRef, useEffect } from 'react';

const useRenderSession = ({
  onClear = (map) => map.clear()
} = {}) => {
  const mapRef = useRef(/* @__PURE__ */ new Map());
  useEffect(() => onClear(mapRef.current));
  return mapRef.current;
};

export { useRenderSession };
