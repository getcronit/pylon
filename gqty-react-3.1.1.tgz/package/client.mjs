import { $meta } from 'gqty';
import { getActivePromises } from 'gqty/Cache/query';
import { createUseMetaState } from './meta/useMetaState.mjs';
import { createUseMutation } from './mutation/useMutation.mjs';
import { createGraphqlHOC } from './query/hoc.mjs';
import { createPrepareQuery } from './query/preparedQuery.mjs';
import { createUseLazyQuery } from './query/useLazyQuery.mjs';
import { createUsePaginatedQuery } from './query/usePaginatedQuery.mjs';
import { createUseQuery } from './query/useQuery.mjs';
import { createUseRefetch } from './query/useRefetch.mjs';
import { createUseTransactionQuery } from './query/useTransactionQuery.mjs';
import { createSSRHelpers } from './ssr/ssr.mjs';
import { createUseSubscription } from './subscription/useSubscription.mjs';

function createReactClient(client, {
  defaults: { suspense = false } = {},
  defaults: {
    initialLoadingState = false,
    transactionFetchPolicy = "cache-first",
    lazyFetchPolicy = "network-only",
    staleWhileRevalidate = false,
    retry = true,
    lazyQuerySuspense = false,
    transactionQuerySuspense = suspense,
    mutationSuspense = false,
    preparedSuspense = suspense,
    refetchAfterHydrate = false,
    paginatedQueryFetchPolicy = "cache-first",
    paginatedQuerySuspense = suspense
  } = {},
  ...options
} = {}) {
  const opts = {
    ...options,
    defaults: {
      initialLoadingState,
      lazyFetchPolicy,
      lazyQuerySuspense,
      mutationSuspense,
      paginatedQueryFetchPolicy,
      paginatedQuerySuspense,
      preparedSuspense,
      refetchAfterHydrate,
      retry,
      staleWhileRevalidate,
      suspense,
      transactionFetchPolicy,
      transactionQuerySuspense
    }
  };
  const { prepareReactRender, useHydrateCache } = createSSRHelpers(
    client,
    opts
  );
  const useQuery = createUseQuery(client, opts);
  return {
    useQuery,
    useRefetch: createUseRefetch(client, opts),
    useLazyQuery: createUseLazyQuery(client, opts),
    useTransactionQuery: createUseTransactionQuery(useQuery, opts),
    usePaginatedQuery: createUsePaginatedQuery(client, opts),
    useMutation: createUseMutation(client, opts),
    graphql: createGraphqlHOC(client, opts),
    state: {
      get isLoading() {
        var _a;
        const cache = (_a = $meta(client.schema.query)) == null ? void 0 : _a.context.cache;
        const promises = cache && getActivePromises(cache);
        return !!(promises == null ? void 0 : promises.length);
      }
    },
    prepareReactRender,
    useHydrateCache,
    useMetaState: createUseMetaState(),
    useSubscription: createUseSubscription(client),
    prepareQuery: createPrepareQuery(client, opts)
  };
}

export { createReactClient };
