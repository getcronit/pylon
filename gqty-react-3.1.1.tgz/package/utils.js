'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function areArraysEqual(a, b) {
  if (a === b) return true;
  if (a == null || b == null) return false;
  const size = a.length;
  if (size !== b.length) return false;
  for (let i = 0; i < size; ++i) if (a[i] !== b[i]) return false;
  return true;
}
function getDefault(v) {
  return ("default" in v ? v.default : v) || v;
}

exports.areArraysEqual = areArraysEqual;
exports.getDefault = getDefault;
