'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const React = require('react');

const useRenderSession = ({
  onClear = (map) => map.clear()
} = {}) => {
  const mapRef = React.useRef(/* @__PURE__ */ new Map());
  React.useEffect(() => onClear(mapRef.current));
  return mapRef.current;
};

exports.useRenderSession = useRenderSession;
