const createMemoryStore = (initialValue) => {
  let state = Object.freeze({ ...initialValue });
  const listeners = /* @__PURE__ */ new Set();
  return {
    add: (value) => {
      state = Object.freeze({ ...state, ...value });
      listeners.forEach((listener) => listener());
    },
    get: () => state,
    set: (value) => {
      state = Object.freeze({ ...value });
      listeners.forEach((listener) => listener());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
};

export { createMemoryStore };
