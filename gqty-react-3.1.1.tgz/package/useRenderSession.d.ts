export type Options<K, V> = {
    onClear?: (map: Map<K, V>) => void;
};
/**
 * Returns a map with its value cleared after each render, useful for
 * render-sensitive state managements.
 */
export declare const useRenderSession: <K, V>({ onClear, }?: Options<K, V>) => Map<K, V>;
