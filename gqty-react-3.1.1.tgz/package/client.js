'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const gqty = require('gqty');
const query = require('gqty/Cache/query');
const useMetaState = require('./meta/useMetaState.js');
const useMutation = require('./mutation/useMutation.js');
const hoc = require('./query/hoc.js');
const preparedQuery = require('./query/preparedQuery.js');
const useLazyQuery = require('./query/useLazyQuery.js');
const usePaginatedQuery = require('./query/usePaginatedQuery.js');
const useQuery = require('./query/useQuery.js');
const useRefetch = require('./query/useRefetch.js');
const useTransactionQuery = require('./query/useTransactionQuery.js');
const ssr = require('./ssr/ssr.js');
const useSubscription = require('./subscription/useSubscription.js');

function createReactClient(client, {
  defaults: { suspense = false } = {},
  defaults: {
    initialLoadingState = false,
    transactionFetchPolicy = "cache-first",
    lazyFetchPolicy = "network-only",
    staleWhileRevalidate = false,
    retry = true,
    lazyQuerySuspense = false,
    transactionQuerySuspense = suspense,
    mutationSuspense = false,
    preparedSuspense = suspense,
    refetchAfterHydrate = false,
    paginatedQueryFetchPolicy = "cache-first",
    paginatedQuerySuspense = suspense
  } = {},
  ...options
} = {}) {
  const opts = {
    ...options,
    defaults: {
      initialLoadingState,
      lazyFetchPolicy,
      lazyQuerySuspense,
      mutationSuspense,
      paginatedQueryFetchPolicy,
      paginatedQuerySuspense,
      preparedSuspense,
      refetchAfterHydrate,
      retry,
      staleWhileRevalidate,
      suspense,
      transactionFetchPolicy,
      transactionQuerySuspense
    }
  };
  const { prepareReactRender, useHydrateCache } = ssr.createSSRHelpers(
    client,
    opts
  );
  const useQuery$1 = useQuery.createUseQuery(client, opts);
  return {
    useQuery: useQuery$1,
    useRefetch: useRefetch.createUseRefetch(client, opts),
    useLazyQuery: useLazyQuery.createUseLazyQuery(client, opts),
    useTransactionQuery: useTransactionQuery.createUseTransactionQuery(useQuery$1, opts),
    usePaginatedQuery: usePaginatedQuery.createUsePaginatedQuery(client, opts),
    useMutation: useMutation.createUseMutation(client, opts),
    graphql: hoc.createGraphqlHOC(client, opts),
    state: {
      get isLoading() {
        var _a;
        const cache = (_a = gqty.$meta(client.schema.query)) == null ? void 0 : _a.context.cache;
        const promises = cache && query.getActivePromises(cache);
        return !!(promises == null ? void 0 : promises.length);
      }
    },
    prepareReactRender,
    useHydrateCache,
    useMetaState: useMetaState.createUseMetaState(),
    useSubscription: useSubscription.createUseSubscription(client),
    prepareQuery: preparedQuery.createPrepareQuery(client, opts)
  };
}

exports.createReactClient = createReactClient;
