import { GQtyError, type BaseGeneratedSchema, type GQtyClient } from 'gqty';
export type UseSubscription<TSchema extends BaseGeneratedSchema> = (options?: UseSubscriptionOptions) => NonNullable<TSchema['subscription']>;
export type UseSubscriptionOptions = {
    onError?: (error: GQtyError) => void;
    operationName?: string;
    /**
     * Throttle delay for each re-redner, prevents busy subscriptions from
     * hanging the UI.
     */
    renderThrottleDelay?: number;
};
export declare function createUseSubscription<TSchema extends BaseGeneratedSchema>({ createResolver, }: GQtyClient<TSchema>): UseSubscription<TSchema>;
