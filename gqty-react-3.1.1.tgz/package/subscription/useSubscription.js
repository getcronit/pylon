'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const web = require('@react-hookz/web');
const gqty = require('gqty');
const React = require('react');

function createUseSubscription({
  createResolver
}) {
  const useSubscription = ({
    onError,
    operationName,
    renderThrottleDelay = 100
  } = {}) => {
    const {
      accessor: { subscription },
      subscribe,
      selections
    } = React.useMemo(() => createResolver({ operationName }), [operationName]);
    const render = web.useRerender();
    const throttledRender = web.useThrottledCallback(
      render,
      [render],
      renderThrottleDelay
    );
    const [error, setError] = React.useState();
    if (error) throw error;
    React.useEffect(() => {
      return subscribe({
        onNext: () => throttledRender(),
        onError(error2) {
          const theError = gqty.GQtyError.create(error2);
          if (onError) {
            onError(theError);
          } else {
            setError(theError);
          }
        }
      });
    }, [onError, selections, selections.size]);
    if (!subscription) {
      throw new gqty.GQtyError(`Subscription is not defined in the schema.`);
    }
    return subscription;
  };
  return useSubscription;
}

exports.createUseSubscription = createUseSubscription;
