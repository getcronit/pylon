import { useRerender } from '@react-hookz/web';
import { useMetaStateHack, GQtyError } from 'gqty';
import * as React from 'react';
import { useExtractedSelections } from '../common.mjs';

function createUseMetaState() {
  const useMetaState = ({
    onStartFetching,
    onDoneFetching,
    onError,
    onRetry,
    filterSelections
  } = {}) => {
    const targetSelections = useExtractedSelections(filterSelections);
    const [promises] = React.useState(() => /* @__PURE__ */ new Set());
    const [errors] = React.useState(() => /* @__PURE__ */ new Set());
    const render = useRerender();
    React.useEffect(() => {
      return useMetaStateHack.subscribeFetch(({ promise, selections }) => {
        if (targetSelections.size > 0) {
          for (const selection of targetSelections) {
            if (selections.has(selection)) return;
          }
        }
        promises.add(promise);
        if (promises.size === 0) {
          errors.clear();
          onStartFetching == null ? void 0 : onStartFetching();
          render();
        }
        promise.catch((error) => {
          const newError = GQtyError.create(error);
          errors.add(newError);
          onError == null ? void 0 : onError({
            newError,
            selections: [...selections],
            isLastTry: true
          });
        }).finally(() => {
          promises.delete(promise);
          if (promises.size === 0) {
            onDoneFetching == null ? void 0 : onDoneFetching();
            render();
          }
        });
      });
    }, []);
    React.useEffect(() => {
      return useMetaStateHack.subscribeRetry(({ promise, selections }) => {
        if (targetSelections.size > 0) {
          for (const selection of targetSelections) {
            if (selections.has(selection)) return;
          }
        }
        onRetry == null ? void 0 : onRetry({
          retryPromise: promise,
          selections
        });
      });
    }, []);
    return Object.freeze({
      isFetching: promises.size > 0,
      errors: [...errors]
    });
  };
  return useMetaState;
}

export { createUseMetaState };
