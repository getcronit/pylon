import { GQtyError, Selection } from 'gqty';
import { type SelectionsOrProxy } from '../common';
export interface UseMetaStateOptions<T extends object> {
    onStartFetching?: () => void;
    onDoneFetching?: () => void;
    onError?: (data: {
        newError: GQtyError;
        selections: Selection[];
        isLastTry: boolean;
    }) => void;
    onRetry?: (data: {
        retryPromise: Promise<unknown>;
        selections: Set<Selection>;
    }) => void;
    filterSelections?: SelectionsOrProxy<T>;
}
export interface MetaState {
    isFetching: boolean;
    errors?: GQtyError[];
}
export interface UseMetaState {
    <T extends object>(opts?: UseMetaStateOptions<T>): MetaState;
}
export declare function createUseMetaState(): UseMetaState;
