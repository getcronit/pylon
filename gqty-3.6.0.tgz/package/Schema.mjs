import memoize from 'just-memoize';

const SchemaUnionsKey = /* @__PURE__ */ Symbol("unionsKey");
const parseSchemaType = memoize(
  (type, fieldDesc = void 0) => {
    let isArray = false;
    let isNullable = true;
    const hasDefaultValue = !!(fieldDesc && fieldDesc.defaultValue !== null);
    let pureType = type;
    let nullableItems = true;
    if (pureType.endsWith("!")) {
      isNullable = false;
      pureType = pureType.slice(0, pureType.length - 1);
    }
    if (pureType.startsWith("[")) {
      pureType = pureType.slice(1, pureType.length - 1);
      isArray = true;
      if (pureType.endsWith("!")) {
        nullableItems = false;
        pureType = pureType.slice(0, pureType.length - 1);
      }
    }
    return {
      pureType,
      isNullable,
      hasDefaultValue,
      isArray,
      nullableItems
    };
  }
);

export { SchemaUnionsKey, parseSchemaType };
