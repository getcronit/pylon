'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const memoize = require('just-memoize');

function _interopDefault (e) { return e && e.__esModule ? e : { 'default': e }; }

const memoize__default = /*#__PURE__*/_interopDefault(memoize);

const SchemaUnionsKey = /* @__PURE__ */ Symbol("unionsKey");
const parseSchemaType = memoize__default["default"](
  (type, fieldDesc = void 0) => {
    let isArray = false;
    let isNullable = true;
    const hasDefaultValue = !!(fieldDesc && fieldDesc.defaultValue !== null);
    let pureType = type;
    let nullableItems = true;
    if (pureType.endsWith("!")) {
      isNullable = false;
      pureType = pureType.slice(0, pureType.length - 1);
    }
    if (pureType.startsWith("[")) {
      pureType = pureType.slice(1, pureType.length - 1);
      isArray = true;
      if (pureType.endsWith("!")) {
        nullableItems = false;
        pureType = pureType.slice(0, pureType.length - 1);
      }
    }
    return {
      pureType,
      isNullable,
      hasDefaultValue,
      isArray,
      nullableItems
    };
  }
);

exports.SchemaUnionsKey = SchemaUnionsKey;
exports.parseSchemaType = parseSchemaType;
