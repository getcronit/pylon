import type { Selection } from '../Selection';
export type RetryEvent = {
    readonly promise: Promise<unknown>;
    readonly selections: Set<Selection>;
    readonly isLastTry: boolean;
};
export declare const notifyRetry: (promise: Promise<unknown>, selections: Set<Selection>, isLastTry?: boolean) => void;
export declare const subscribeRetry: (callback: (event: RetryEvent) => void) => () => void;
export type FetchEvent = {
    readonly promise: Promise<unknown>;
    readonly selections: Set<Selection>;
};
export declare const notifyFetch: (promise: Promise<unknown>, selections: Set<Selection>) => void;
export declare const subscribeFetch: (callback: (event: FetchEvent) => void) => () => void;
