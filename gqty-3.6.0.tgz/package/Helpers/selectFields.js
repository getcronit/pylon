'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const get = require('just-safe-get');
const set = require('just-safe-set');
require('../Utils/hash.js');
const object = require('../Utils/object.js');

function _interopDefault (e) { return e && e.__esModule ? e : { 'default': e }; }

const get__default = /*#__PURE__*/_interopDefault(get);
const set__default = /*#__PURE__*/_interopDefault(set);

function selectFields(accessor, fields = "*", recursionDepth = 1) {
  if (accessor == null) return accessor;
  if (Array.isArray(accessor)) {
    return accessor.map(
      (value) => selectFields(value, fields, recursionDepth)
    );
  } else if (!object.isObject(accessor)) {
    return accessor;
  } else {
    Reflect.get(accessor, "__typename");
  }
  if (fields.length === 0) {
    return {};
  }
  if (typeof fields === "string") {
    if (recursionDepth > 0) {
      const allAccessorKeys = Object.keys(accessor);
      return allAccessorKeys.reduce((acum, fieldName) => {
        const fieldValue = get__default["default"](accessor, fieldName);
        if (Array.isArray(fieldValue)) {
          set__default["default"](
            acum,
            fieldName,
            fieldValue.map((value) => {
              return selectFields(value, "*", recursionDepth - 1);
            })
          );
        } else if (object.isObject(fieldValue)) {
          set__default["default"](
            acum,
            fieldName,
            selectFields(fieldValue, "*", recursionDepth - 1)
          );
        } else {
          set__default["default"](acum, fieldName, fieldValue);
        }
        return acum;
      }, {});
    } else {
      return null;
    }
  }
  return fields.reduce((acum, fieldName) => {
    if (typeof fieldName === "number") {
      fieldName = fieldName.toString();
    }
    const fieldValue = get__default["default"](accessor, fieldName);
    if (fieldValue === void 0) return acum;
    if (Array.isArray(fieldValue)) {
      set__default["default"](
        acum,
        fieldName,
        fieldValue.map((value) => {
          return selectFields(value, "*", recursionDepth);
        })
      );
    } else if (object.isObject(fieldValue)) {
      set__default["default"](acum, fieldName, selectFields(fieldValue, "*", recursionDepth));
    } else {
      set__default["default"](acum, fieldName, fieldValue);
    }
    return acum;
  }, {});
}

exports.selectFields = selectFields;
