'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const flatted = require('flatted');

const deepCopy = (value) => (
  // structuredClone does not support WeakRef, fallback to serialization.
  Object.freeze(flatted.parse(flatted.stringify(value)))
);

exports.deepCopy = deepCopy;
