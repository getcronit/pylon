const noop = (v) => v;
const castNotSkeletonDeep = noop;
const castNotSkeleton = noop;

export { castNotSkeleton, castNotSkeletonDeep };
