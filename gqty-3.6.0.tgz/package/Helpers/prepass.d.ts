import type { Selection } from '../Selection';
export interface PrepassObjKey {
    field: string;
    variables?: Record<string, unknown>;
}
export declare function prepass<T extends object | null | undefined>(v: T, ...keys: Array<string | Array<string | PrepassObjKey>>): T;
export declare function prepass<T extends object | null | undefined>(v: T, selections: Set<Selection>): T;
