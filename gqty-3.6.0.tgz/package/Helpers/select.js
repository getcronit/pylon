'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function select(node, path, onNext) {
  const probedNode = onNext ? onNext(node, path) : node;
  if (path.length === 0) {
    return node;
  } else if (probedNode == null || typeof probedNode !== "object") {
    return probedNode === null ? null : void 0;
  }
  if (Array.isArray(probedNode)) {
    return probedNode.map((item) => select(item, path, onNext));
  }
  const [key, ...rest] = path;
  return select(probedNode[key], rest, onNext);
}

exports.select = select;
