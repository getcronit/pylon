const retryEventListeners = /* @__PURE__ */ new Set();
const notifyRetry = (promise, selections, isLastTry = false) => {
  for (const listener of retryEventListeners) {
    listener({ promise, selections, isLastTry });
  }
};
const subscribeRetry = (callback) => {
  retryEventListeners.add(callback);
  return () => {
    retryEventListeners.delete(callback);
  };
};
const fetchEventListeners = /* @__PURE__ */ new Set();
const notifyFetch = (promise, selections) => {
  for (const listener of fetchEventListeners) {
    listener({ promise, selections });
  }
};
const subscribeFetch = (callback) => {
  fetchEventListeners.add(callback);
  return () => {
    fetchEventListeners.delete(callback);
  };
};

export { notifyFetch, notifyRetry, subscribeFetch, subscribeRetry };
