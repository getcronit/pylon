import { FrailMap } from 'frail-map';
export declare class InfiniteFrailMap<K extends object, V> extends FrailMap<K, V | InfiniteFrailMap<K, V | InfiniteFrailMap<K, V>>> {
    get(key: K): V | InfiniteFrailMap<K, V | InfiniteFrailMap<K, V>>;
}
