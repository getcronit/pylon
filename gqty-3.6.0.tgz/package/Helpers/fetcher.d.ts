import { type ExecutionResult } from 'graphql';
export declare const defaultResponseHandler: (response: Response) => Promise<ExecutionResult<import("graphql/jsutils/ObjMap").ObjMap<unknown>, import("graphql/jsutils/ObjMap").ObjMap<unknown>>>;
export declare const parseResponse: (response: Response) => Promise<any>;
export declare function assertExecutionResult(input: unknown): asserts input is ExecutionResult;
export declare const isExecutionResult: (input: unknown) => input is ExecutionResult;
export declare const handleResponseErrors: (result: ExecutionResult) => void;
