'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('../Utils/hash.js');
const object = require('../Utils/object.js');

function getFields(accessor, ...keys) {
  if (!object.isObject(accessor)) return accessor;
  if (keys.length) for (const key of keys) Reflect.get(accessor, key);
  else for (const key in accessor) Reflect.get(accessor, key);
  return accessor;
}
function getArrayFields(accessorArray, ...keys) {
  if (accessorArray == null) return accessorArray;
  if (Array.isArray(accessorArray)) {
    for (const value of accessorArray) {
      if (object.isPlainObject(value)) {
        getFields(value, ...keys);
        break;
      }
    }
  }
  return accessorArray;
}

exports.getArrayFields = getArrayFields;
exports.getFields = getFields;
