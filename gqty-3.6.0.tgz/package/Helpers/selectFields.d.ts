export declare function selectFields<A extends object | null | undefined>(accessor: A, fields?: '*' | Array<string | number>, recursionDepth?: number): A;
