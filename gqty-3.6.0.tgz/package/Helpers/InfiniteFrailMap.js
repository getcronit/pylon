'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const frailMap = require('frail-map');

class InfiniteFrailMap extends frailMap.FrailMap {
  get(key) {
    var _a;
    const value = (_a = super.get(key)) != null ? _a : new InfiniteFrailMap();
    super.set(key, value);
    return value;
  }
}

exports.InfiniteFrailMap = InfiniteFrailMap;
