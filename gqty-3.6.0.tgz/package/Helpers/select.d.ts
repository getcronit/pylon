import type { CacheNode } from '../Cache';
/**
 * Similar to _.get() but dots goes into arrays, JSONata, JSONPath and JMESPath
 * does similar things but overkill.
 */
export declare function select(node: CacheNode, path: string[], 
/**
 * Optional callback, invoked each time a path segment can be successfully
 * traversed downwards. The callback can return a new node value to replace
 * the current node, return `undefined` to essentially terminate the
 * traversal.
 */
onNext?: (node: CacheNode, path: string[]) => CacheNode): CacheNode;
