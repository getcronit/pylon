import '../Utils/hash.mjs';
import { isObject } from '../Utils/object.mjs';

function getFirstNonNullValue(list) {
  for (const value of list) if (value != null) return value;
}
function prepass(v, ...keys) {
  if (v == null) return v;
  keys = keys[0] instanceof Set ? keys = [...keys[0]].map((selection) => {
    return selection.ancestry.map(
      (s) => s.input ? {
        field: `${s.key}`,
        variables: s.input.values
      } : `${s.key}`
    );
  }) : keys;
  for (const composedKeys of keys) {
    const separatedKeys = typeof composedKeys === "string" ? composedKeys.split(".") : composedKeys;
    let obj = v;
    for (const key of separatedKeys) {
      if (obj && key) {
        const field = typeof key === "object" ? key.field : key;
        const variables = typeof key === "object" ? key.variables : void 0;
        if (Array.isArray(obj)) {
          const firstNonNull = getFirstNonNullValue(obj);
          if (firstNonNull) {
            obj = firstNonNull;
          } else break;
        }
        if (isObject(obj)) {
          if (field in obj) {
            const value = obj[field];
            if (typeof value === "function") {
              obj = value(variables);
            } else {
              obj = value;
            }
          } else break;
        } else break;
      } else break;
    }
  }
  return v;
}

export { prepass };
