import { FrailMap } from 'frail-map';

class InfiniteFrailMap extends FrailMap {
  get(key) {
    var _a;
    const value = (_a = super.get(key)) != null ? _a : new InfiniteFrailMap();
    super.set(key, value);
    return value;
  }
}

export { InfiniteFrailMap };
