import { parse, stringify } from 'flatted';

const deepCopy = (value) => (
  // structuredClone does not support WeakRef, fallback to serialization.
  Object.freeze(parse(stringify(value)))
);

export { deepCopy };
