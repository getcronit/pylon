export declare const deepCopy: <T>(value: T) => Readonly<T>;
