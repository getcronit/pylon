import get from 'just-safe-get';
import set from 'just-safe-set';
import '../Utils/hash.mjs';
import { isObject } from '../Utils/object.mjs';

function selectFields(accessor, fields = "*", recursionDepth = 1) {
  if (accessor == null) return accessor;
  if (Array.isArray(accessor)) {
    return accessor.map(
      (value) => selectFields(value, fields, recursionDepth)
    );
  } else if (!isObject(accessor)) {
    return accessor;
  } else {
    Reflect.get(accessor, "__typename");
  }
  if (fields.length === 0) {
    return {};
  }
  if (typeof fields === "string") {
    if (recursionDepth > 0) {
      const allAccessorKeys = Object.keys(accessor);
      return allAccessorKeys.reduce((acum, fieldName) => {
        const fieldValue = get(accessor, fieldName);
        if (Array.isArray(fieldValue)) {
          set(
            acum,
            fieldName,
            fieldValue.map((value) => {
              return selectFields(value, "*", recursionDepth - 1);
            })
          );
        } else if (isObject(fieldValue)) {
          set(
            acum,
            fieldName,
            selectFields(fieldValue, "*", recursionDepth - 1)
          );
        } else {
          set(acum, fieldName, fieldValue);
        }
        return acum;
      }, {});
    } else {
      return null;
    }
  }
  return fields.reduce((acum, fieldName) => {
    if (typeof fieldName === "number") {
      fieldName = fieldName.toString();
    }
    const fieldValue = get(accessor, fieldName);
    if (fieldValue === void 0) return acum;
    if (Array.isArray(fieldValue)) {
      set(
        acum,
        fieldName,
        fieldValue.map((value) => {
          return selectFields(value, "*", recursionDepth);
        })
      );
    } else if (isObject(fieldValue)) {
      set(acum, fieldName, selectFields(fieldValue, "*", recursionDepth));
    } else {
      set(acum, fieldName, fieldValue);
    }
    return acum;
  }, {});
}

export { selectFields };
