'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const noop = (v) => v;
const castNotSkeletonDeep = noop;
const castNotSkeleton = noop;

exports.castNotSkeleton = castNotSkeleton;
exports.castNotSkeletonDeep = castNotSkeletonDeep;
