import '../Utils/hash.mjs';
import { isObject, isPlainObject } from '../Utils/object.mjs';

function getFields(accessor, ...keys) {
  if (!isObject(accessor)) return accessor;
  if (keys.length) for (const key of keys) Reflect.get(accessor, key);
  else for (const key in accessor) Reflect.get(accessor, key);
  return accessor;
}
function getArrayFields(accessorArray, ...keys) {
  if (accessorArray == null) return accessorArray;
  if (Array.isArray(accessorArray)) {
    for (const value of accessorArray) {
      if (isPlainObject(value)) {
        getFields(value, ...keys);
        break;
      }
    }
  }
  return accessorArray;
}

export { getArrayFields, getFields };
