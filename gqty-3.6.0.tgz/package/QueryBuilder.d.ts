import type { Cache } from './Cache';
import type { QueryPayload } from './Schema';
import type { Selection } from './Selection';
export type QueryBuilderOptions = {
    batchWindow: number;
    batchStrategy: 'debounce' | 'throttle';
    cache: Cache;
};
type RootType = 'query' | 'mutation' | 'subscription';
export type BuiltQuery = QueryPayload<{
    type: RootType;
    hash: string;
}>;
export declare const buildQuery: (selections: Set<Selection>, operationName?: string) => BuiltQuery[];
export {};
