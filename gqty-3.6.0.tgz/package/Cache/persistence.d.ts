import { FrailMap } from 'frail-map';
import type { Cache, CacheLeaf, CacheNode, CacheObject, CacheRoot } from '.';
import { type CacheNormalizationHandler, type NormalizedObjectShell } from './normalization';
export type Persistors = {
    persist(version?: string): CacheSnapshot;
    restore(snapshot: CacheSnapshot, version?: string): boolean;
    restoreAsync(snapshot: () => Promise<CacheSnapshot>, version?: string): Promise<boolean>;
};
/** Exported cache shape, for cache initialization and persistence. */
export type CacheSnapshot = {
    query?: Record<string, CacheSnapshotNode>;
    mutation?: Record<string, CacheSnapshotNode>;
    subscription?: Record<string, CacheSnapshotNode>;
    normalized?: Record<string, CacheSnapshotObject>;
    version?: string;
};
export type CacheSnapshotOutput = {
    query?: Record<string, CacheNode>;
    mutation?: Record<string, CacheNode>;
    subscription?: Record<string, CacheNode>;
    normalizedObjects?: FrailMap<string, NormalizedObjectShell<CacheObject>>;
};
export type CacheSnapshotObject = {
    __typename: string;
    [key: string]: CacheSnapshotNode | CacheLeaf;
};
export type CacheReference = {
    __ref: string;
};
export type CacheSnapshotNode = CacheLeaf | CacheObject | CacheReference | CacheSnapshotNode[] | CacheSnapshotObject;
export declare const isCacheSnapshotObject: (value: unknown) => value is CacheSnapshotObject;
export declare const isCacheReference: (value: unknown) => value is CacheReference;
export declare const importCacheSnapshot: (snapshot: CacheSnapshot, options?: CacheNormalizationHandler) => CacheSnapshotOutput;
/**
 * Cache may contain circular reference of objects. To properly serialize it,
 * use `flatted` or `@ungap/structured-clone`.
 */
export declare const exportCacheSnapshot: ({ query, mutation, subscription }: CacheRoot, options?: CacheNormalizationHandler) => CacheSnapshot;
export declare const createPersistors: (cache: Cache) => Persistors;
