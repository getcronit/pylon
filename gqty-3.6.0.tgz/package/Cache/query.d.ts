import type { ExecutionResult } from 'graphql';
import type { Cache } from '.';
/**
 * Keep track of ongoing promises, identified by a provided hash.
 *
 * Before the promise is resolved, subsequent requests with the same hash
 * gets the same promise.
 *
 * After promise resolution, the hash is removed from the map.
 *
 * If the `cache` argument is omitted, a global cache will be used instead.
 */
export declare const dedupePromise: <TData = Record<string, unknown>, TExtensions = Record<string, unknown>>(cache: Cache | undefined, hash: string, fetchOrSubscribe: () => Promise<ExecutionResult<TData, TExtensions> | void>) => Promise<ExecutionResult<TData, TExtensions>>;
/** Retrieve active promises associated provided cache, useful for SSR. */
export declare const getActivePromises: (cache?: Cache) => Promise<ExecutionResult>[];
