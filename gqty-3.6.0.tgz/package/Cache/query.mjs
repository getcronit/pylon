const nullObjectKey = {};
const deduplicationCache = new WeakMap([[nullObjectKey, /* @__PURE__ */ new Map()]]);
const dedupePromise = (cache, hash, fetchOrSubscribe) => {
  var _a, _b;
  const key = cache != null ? cache : nullObjectKey;
  const queryHashMap = (_a = deduplicationCache.get(key)) != null ? _a : /* @__PURE__ */ new Map();
  if (!deduplicationCache.has(key)) {
    deduplicationCache.set(key, queryHashMap);
  }
  const cachedQueryPromise = (_b = queryHashMap.get(hash)) != null ? _b : fetchOrSubscribe().finally(() => {
    queryHashMap.delete(hash);
  });
  if (!queryHashMap.has(hash)) {
    queryHashMap.set(hash, cachedQueryPromise);
  }
  return cachedQueryPromise;
};
const getActivePromises = (cache) => {
  var _a, _b;
  return [
    ...(_b = (_a = deduplicationCache.get(cache != null ? cache : nullObjectKey)) == null ? void 0 : _a.values()) != null ? _b : []
  ];
};

export { dedupePromise, getActivePromises };
