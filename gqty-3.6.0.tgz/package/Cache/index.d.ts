import { type CacheNormalizationHandler } from './normalization';
import { type CacheSnapshot } from './persistence';
export type CacheRoot = {
    query?: CacheObject;
    mutation?: CacheObject;
    subscription?: CacheObject;
};
export type CacheNode = CacheLeaf | CacheNode[] | CacheObject;
export type CacheObject = {
    __typename?: string;
    [key: string]: CacheNode | CacheLeaf;
};
export type CacheLeaf = string | number | boolean | null | undefined;
export type CacheOptions = {
    /**
     * Maximum age of cache data in milliseconds, expired data nodes are subjected
     * to garbage collection.
     *
     * @default Infinity
     */
    readonly maxAge?: number;
    /**
     * `false` to disable normalized cache, which usually means manual
     * refetching after mutations.
     */
    readonly normalization?: boolean | CacheNormalizationHandler;
    /**
     * Maximum time in milliseconds to keep stale data in cache, while allowing
     * stale-while-revalidate background fetches.
     *
     * @default 0
     */
    readonly staleWhileRevalidate?: number;
};
export type CacheDataContainer<TData extends CacheNode = CacheNode> = {
    data: TData;
    /**
     * data is open to TTL eviction after this time, before that only LRU eviction
     * may take place.
     */
    expiresAt: number;
    /**
     * A hint for clients to revaliate, does not affect automatic cache eviction.
     */
    swrBefore?: number;
    /**
     * Remove internal data reference, allowing WeakRefs to be garbage collected.
     *
     * For StrongRefs, calling this function has no effect.
     */
    unref?: () => void;
};
export type CacheListener = <TData extends CacheNode = CacheNode>(value: TData) => void;
export type CacheGetOptions = {
    includeExpired?: boolean;
};
export type CacheSetOptions = {
    skipNotify?: boolean;
};
/**
 * A scoped cache for accessors, selections and data with expiry awareness.
 */
export declare class Cache {
    #private;
    /**
     * Maximum age of cache data in milliseconds, expired data nodes are subjected
     * to garbage collection.
     */
    get maxAge(): number;
    /**
     * Maximum time in milliseconds to keep stale data in cache, while allowing
     * stale-while-revalidate background fetches.
     */
    get staleWhileRevalidate(): number;
    get normalizationOptions(): CacheNormalizationHandler | undefined;
    constructor(data?: CacheSnapshot, { maxAge, staleWhileRevalidate, normalization, }?: CacheOptions);
    restore(data: CacheSnapshot): void;
    /** Subscribe to cache changes. */
    subscribe(fn: CacheListener): () => void;
    subscribe(paths: string[], fn: CacheListener): () => void;
    /**
     * Retrieve cache values by first 2 path segments, e.g. `query.todos` or
     * `mutation.createTodo`.
     */
    get(path: string, options?: CacheGetOptions): CacheDataContainer | undefined;
    /**
     * Merge objects into the current cache, recursively normalize incoming values
     * if normalization is enabled. Notifies cache listeners afterwards.
     *
     * Example value: `{ query: { foo: "bar" } }`
     */
    set(values: CacheRoot, { skipNotify }?: CacheSetOptions): void;
    clear(): void;
    toJSON(): CacheSnapshot;
}
