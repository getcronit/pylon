/**
 * Stack-based deep crawl, avoiding recursions.
 */
export declare const crawl: (data: any, fn: (it: any, key: string | number, parent: Record<string, any> | any[]) => [any, any, any] | void, maxIterations?: number) => any;
export declare const flattenObject: (obj: Record<string, unknown>, maxIterations?: number) => [string[], string | number | boolean | null][];
