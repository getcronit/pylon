'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const isCacheObject = (value) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  const obj = value;
  if (obj.__typename && typeof obj.__typename !== "string") return false;
  return true;
};
const isCacheObjectArray = (value) => Array.isArray(value) && value.every(isCacheObject);

exports.isCacheObject = isCacheObject;
exports.isCacheObjectArray = isCacheObjectArray;
