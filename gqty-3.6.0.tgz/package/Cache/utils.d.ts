import type { CacheObject } from '.';
export declare const isCacheObject: (value: unknown) => value is CacheObject;
export declare const isCacheObjectArray: (value: unknown) => value is CacheObject[];
