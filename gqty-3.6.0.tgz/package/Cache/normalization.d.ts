import type { FrailMap } from 'frail-map';
import type { CacheNode, CacheObject } from '.';
export type NormalizedObjectShell<TData extends CacheObject = CacheObject> = TData & {
    $set(value: TData): void;
    toJSON(): TData;
};
export declare const isNormalizedObjectShell: (value: unknown) => value is NormalizedObjectShell;
export type NormalizatioOptions<TData extends CacheObject = CacheObject> = CacheNormalizationHandler & {
    store: FrailMap<string, NormalizedObjectShell<TData>>;
};
/**
 * Update the store with incoming data, merge or replace them depends on
 * provided handlers.
 */
export declare const normalizeObject: <TData extends CacheObject>(data: TData, { identity, onConflict, store }: NormalizatioOptions<TData>) => NormalizedObjectShell<TData> | undefined;
/**
 * Recursively replace normalize input objects with the provided store.
 */
export declare const deepNormalizeObject: <TData extends CacheNode>(data: TData, options: NormalizatioOptions) => TData;
export type CacheNormalizationHandler = {
    /**
     * To disable normalization for a particular object, return undefined.
     */
    identity(value: CacheNode): string | undefined;
    onConflict?(
    /** Existing value */
    sourceValue: object, 
    /** Incoming value */
    targetValue: object): object | undefined;
    schemaKeys?: Record<string, string[]>;
};
export declare const defaultNormalizationHandler: CacheNormalizationHandler;
export declare const isSubsetOf: (a: CacheObject, b: CacheObject) => boolean;
