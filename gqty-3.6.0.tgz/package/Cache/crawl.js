'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const InfiniteFrailMap = require('../Helpers/InfiniteFrailMap.js');

const crawl = (data, fn, maxIterations = 1e5) => {
  const seen = new InfiniteFrailMap.InfiniteFrailMap();
  const stack = /* @__PURE__ */ new Set([[data, 0, []]]);
  for (const [it, key, obj] of stack) {
    if (maxIterations-- < 0) {
      throw new Error("Maximum iterations reached.");
    }
    if (seen.get(it).get(key).has(obj)) continue;
    seen.get(it).get(key).set(obj, true);
    const ret = fn(it, key, obj);
    if (ret !== void 0) {
      stack.add(ret);
    }
    if (it === void 0) {
      delete obj[key];
    } else if (Array.isArray(it)) {
      for (const [k, v] of it.entries()) stack.add([v, k, it]);
    } else if (typeof it === "object" && it !== null) {
      for (const [k, v] of Object.entries(it)) stack.add([v, k, it]);
    }
  }
  return data;
};
const flattenObject = (obj, maxIterations = 1e5) => {
  const result = [];
  const stack = /* @__PURE__ */ new Set([[[], obj]]);
  const seen = /* @__PURE__ */ new Set();
  for (const [key, it] of stack) {
    if (maxIterations-- < 0) {
      throw new Error("Maximum iterations reached.");
    }
    if (it === void 0) continue;
    if (it === null || typeof it === "string" || typeof it === "number" || typeof it === "boolean") {
      result.push([key, it]);
    } else {
      if (seen.has(it)) continue;
      seen.add(it);
      if (Array.isArray(it)) {
        for (const [k, v] of it.entries()) stack.add([[...key, `${k}`], v]);
      } else if (typeof it === "object") {
        for (const [k, v] of Object.entries(it))
          stack.add([[...key, `${k}`], v]);
      }
    }
  }
  return result;
};

exports.crawl = crawl;
exports.flattenObject = flattenObject;
