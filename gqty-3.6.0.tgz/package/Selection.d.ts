export type SelectionOptions = {
    readonly alias?: string;
    readonly aliasLength?: number;
    readonly input?: SelectionInput;
    readonly isUnion?: boolean;
    readonly parent?: Selection;
};
export type SelectionInput = {
    readonly types: Record<string, string>;
    readonly values: Record<string, unknown>;
};
export type SelectionSnapshot = Array<[
    string | number,
    SelectionOptions
] | [string | number]>;
export declare class Selection {
    readonly key: string | number;
    readonly options: SelectionOptions;
    readonly children: Map<string | number, Selection>;
    constructor(key: string | number, options?: SelectionOptions, token?: symbol);
    get alias(): string | undefined;
    get aliasLength(): number | undefined;
    get input(): SelectionInput | undefined;
    /** Indicates current selection being a inteface/union key. */
    get isUnion(): boolean;
    get parent(): Selection | undefined;
    get root(): Selection;
    get cacheKeys(): string[];
    /** The selection path from root the leaf as an array. */
    get ancestry(): Selection[];
    static createRoot(key: string, options?: SelectionOptions): Selection;
    getChild(key: string | number, options?: SelectionOptions): Selection;
    getLeafNodes(this: Selection): Set<Selection>;
    toJSON(): SelectionSnapshot;
    fromJSON(this: Selection, json: SelectionSnapshot): Selection;
    get [Symbol.toStringTag](): string;
    toString(): string;
}
