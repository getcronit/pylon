import type { CacheDataContainer, CacheNode } from '../Cache';
import type { SchemaContext } from '../Client';
import type { Type } from '../Schema';
import type { Selection } from '../Selection';
export type Meta = {
    context: SchemaContext;
    cache: CacheDataContainer<CacheNode>;
    selection: Selection;
    /** Object type definition from the geneated schema. */
    type: Type;
};
export declare const $meta: {
    <T extends object>(accessor: T): Meta | undefined;
    set(accessor: object, meta: Meta): void;
};
