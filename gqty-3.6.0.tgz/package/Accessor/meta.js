'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const metaverse = /* @__PURE__ */ new WeakMap();
const $meta = (accessor) => metaverse.get(accessor);
$meta.set = (accessor, meta) => {
  metaverse.set(accessor, meta);
};

exports.$meta = $meta;
