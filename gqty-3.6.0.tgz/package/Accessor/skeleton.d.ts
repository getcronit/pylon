export declare const isSkeleton: (object: unknown) => boolean;
/** Create data skeleton array/objects. */
export declare const createSkeleton: <T extends WeakKey>(fn: () => T) => T;
