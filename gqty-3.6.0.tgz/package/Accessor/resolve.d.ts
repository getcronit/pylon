import type { CacheNode } from '../Cache';
import { type GeneratedSchemaObject, type Type } from '../Schema';
import type { Selection } from '../Selection';
import type { Meta } from './meta';
/**
 * Check provided accessor with the new selection, returns appropriate
 * accessors, data skeleton or cached value according to the generated schema.
 */
export declare const resolve: (accessor: GeneratedSchemaObject, 
/** Incoming new selection to check against the accessor. */
selection: Selection, __type: Type["__type"]) => string | number | boolean | CacheNode[] | GeneratedSchemaObject | {
    [k: string]: boolean;
} | null | undefined;
export declare const createUnionAccessor: ({ context, cache, possibleTypes, selection, }: Omit<Meta, "type"> & {
    possibleTypes: readonly string[];
}) => {
    [k: string]: boolean;
};
export type AccessorOptions = {
    type: Record<string, Type | undefined>;
};
export declare const createObjectAccessor: <TSchemaType extends GeneratedSchemaObject>(meta: Meta) => GeneratedSchemaObject;
/** Recursively replace proxy accessors with its actual cached value. */
export declare const deepMetadata: (input: Record<string, unknown>) => Record<string, unknown>;
export declare const createArrayAccessor: (meta: Meta) => CacheNode[];
