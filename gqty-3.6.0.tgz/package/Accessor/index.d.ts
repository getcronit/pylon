import type { BaseGeneratedSchema, SchemaContext } from '../Client';
import type { GeneratedSchemaObject } from '../Schema';
export { $meta } from './meta';
export declare function createSchemaAccessor<TSchema extends BaseGeneratedSchema>(context: SchemaContext): {
    accessor: TSchema;
    clearCache: () => void;
};
/**
 * Handler for object level data updates.
 */
export declare const setCache: <TData extends GeneratedSchemaObject>(accessor: TData, data: Partial<TData>) => void;
/**
 * Use another accessor like a fragment, this function takes all children from
 * the donor and runs it again on the accessor.
 *
 * Useful when you want to query the eaxact same fields from a mutation.
 */
export declare const assignSelections: <TData extends GeneratedSchemaObject>(source: TData | null, target: TData | null) => void;
