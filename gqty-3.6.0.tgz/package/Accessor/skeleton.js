'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('../Utils/hash.js');
const object = require('../Utils/object.js');
const meta = require('./meta.js');

const skeletons = /* @__PURE__ */ new WeakSet();
const isSkeleton = (object$1) => {
  var _a;
  if (!object.isObject(object$1)) return false;
  const value = object$1;
  if (skeletons.has(value)) return true;
  const data = (_a = meta.$meta(value)) == null ? void 0 : _a.cache.data;
  if (!object.isObject(data)) return false;
  return skeletons.has(data);
};
const createSkeleton = (fn) => {
  const skeleton = fn();
  skeletons.add(skeleton);
  return skeleton;
};

exports.createSkeleton = createSkeleton;
exports.isSkeleton = isSkeleton;
