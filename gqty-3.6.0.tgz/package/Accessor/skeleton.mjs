import '../Utils/hash.mjs';
import { isObject } from '../Utils/object.mjs';
import { $meta } from './meta.mjs';

const skeletons = /* @__PURE__ */ new WeakSet();
const isSkeleton = (object) => {
  var _a;
  if (!isObject(object)) return false;
  const value = object;
  if (skeletons.has(value)) return true;
  const data = (_a = $meta(value)) == null ? void 0 : _a.cache.data;
  if (!isObject(data)) return false;
  return skeletons.has(data);
};
const createSkeleton = (fn) => {
  const skeleton = fn();
  skeletons.add(skeleton);
  return skeleton;
};

export { createSkeleton, isSkeleton };
