const metaverse = /* @__PURE__ */ new WeakMap();
const $meta = (accessor) => metaverse.get(accessor);
$meta.set = (accessor, meta) => {
  metaverse.set(accessor, meta);
};

export { $meta };
