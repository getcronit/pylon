'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const createDebugger = () => {
  const subs = /* @__PURE__ */ new Set();
  return {
    dispatch: async (event) => {
      await Promise.all([...subs].map((sub) => sub(event)));
    },
    subscribe: (listener) => {
      subs.add(listener);
      return () => subs.delete(listener);
    }
  };
};

exports.createDebugger = createDebugger;
