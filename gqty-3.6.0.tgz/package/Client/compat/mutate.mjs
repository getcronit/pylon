import { setCache, assignSelections } from '../../Accessor/index.mjs';
import { GQtyError } from '../../Error/index.mjs';

const createLegacyMutate = ({
  accessor,
  resolvers: { resolve }
}) => async (fn, { onComplete, onError } = {}) => {
  try {
    const data = await resolve(({ mutation }) => fn(mutation), {
      cachePolicy: "no-cache"
    });
    onComplete == null ? void 0 : onComplete(data, {
      query: accessor.query,
      setCache,
      assignSelections
    });
    return data;
  } catch (e) {
    if (e instanceof GQtyError) {
      onError == null ? void 0 : onError(e, {
        query: accessor.query,
        setCache,
        assignSelections
      });
    }
    throw e;
  }
};

export { createLegacyMutate };
