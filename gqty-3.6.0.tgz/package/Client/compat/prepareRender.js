'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const flatted = require('flatted');
const skeleton = require('../../Accessor/skeleton.js');
const index = require('../../Cache/index.js');
require('../../Utils/hash.js');
const object = require('../../Utils/object.js');
const resolveSelections = require('../resolveSelections.js');
const updateCaches = require('../updateCaches.js');

const isLegacyCacheSnapshot = (json) => {
  if (json != null && !object.isPlainObject(json)) {
    return false;
  }
  const snapshot = json;
  if (snapshot.cache !== void 0 && !object.isPlainObject(snapshot.cache)) {
    return false;
  }
  if (snapshot.selections) {
    if (!Array.isArray(snapshot.selections)) {
      return false;
    }
    if (!snapshot.selections.every((selection) => {
      if (!Array.isArray(selection) || !selection.every((it) => {
        if (!Array.isArray(it)) return false;
        if (typeof it[0] !== "string" && typeof it[0] !== "number")
          return false;
        if (it[1] && (!object.isPlainObject(it[1]) || !object.isPlainObject(it[1].input) || it[1].isUnion !== void 0 && it[1].isUnion !== true))
          return false;
        return true;
      }))
        return false;
      return true;
    }))
      return false;
  }
  return true;
};
const createLegacyPrepareRender = ({
  cache,
  debugger: debug,
  fetchOptions,
  subscribeLegacySelections
}) => {
  return async (render) => {
    const ssrCache = new index.Cache();
    const selections = /* @__PURE__ */ new Set();
    const unsubscribe = subscribeLegacySelections((selection) => {
      selections.add(selection);
    });
    try {
      await render();
    } finally {
      unsubscribe();
    }
    await resolveSelections.fetchSelections(
      new Set(
        [...selections].filter((s) => {
          if (s.root.key === "subscription") return false;
          const cacheKey = s.cacheKeys.join(".");
          const dataContainer = cache.get(cacheKey);
          const data = dataContainer == null ? void 0 : dataContainer.data;
          const hasMissing = (val) => {
            if (val === void 0 || skeleton.isSkeleton(val)) return true;
            if (Array.isArray(val)) return val.some(hasMissing);
            return false;
          };
          return hasMissing(data);
        })
      ),
      {
        cache,
        debugger: debug,
        fetchOptions
      }
    ).then(
      (results) => updateCaches.updateCaches(results, [cache, ssrCache], { skipNotify: true })
    );
    return {
      cacheSnapshot: flatted.toJSON(
        Object.keys(cache.toJSON()).length > 0 ? selections.size > 0 ? { cache, selections: [...selections] } : { cache } : {}
      )
    };
  };
};

exports.createLegacyPrepareRender = createLegacyPrepareRender;
exports.isLegacyCacheSnapshot = isLegacyCacheSnapshot;
