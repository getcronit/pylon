import type { Client } from 'graphql-ws';
import { GQtyError } from '../../Error';
import type { LegacySelection as Selection } from './selection';
type Promisable<T> = T | Promise<T>;
export type LegacySubscriptionsClient<TData extends Record<string, unknown> = Record<string, unknown>> = {
    subscribe(opts: {
        query: string;
        variables: Record<string, unknown> | undefined;
        selections: Selection[];
        events: ((ctx: {
            selections: Selection[];
            query: string;
            variables: Record<string, unknown> | undefined;
            operationId: string;
        }) => LegacySubscribeEvents<TData>) | LegacySubscribeEvents;
        cacheKey?: string;
    }): Promisable<{
        unsubscribe: () => Promise<void>;
        operationId: string;
    }>;
    unsubscribe(selections: Selection[] | Set<Selection>): Promise<string[]>;
    close(): Promise<void>;
    setConnectionParams(connectionParams: (() => Promisable<Record<string, unknown>>) | Record<string, unknown>, restartClient?: boolean): void;
};
export interface LegacySubscribeEvents<TData extends Record<string, unknown> = Record<string, unknown>> {
    onData: (data: TData) => void;
    onError: (payload: {
        error: GQtyError;
        data: TData | null;
    }) => void;
    onStart?: () => void;
    onComplete?: () => void;
}
export declare const createLegacySubscriptionsClient: (subscriptionsClient: LegacySubscriptionsClient) => Client;
export {};
