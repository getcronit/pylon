'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const flatted = require('flatted');
const index = require('../../Error/index.js');
require('../../Utils/hash.js');
const meta = require('../../Accessor/meta.js');
require('../../Accessor/resolve.js');
const resolveSelections = require('../resolveSelections.js');
const updateCaches = require('../updateCaches.js');
const prepareRender = require('./prepareRender.js');

const createLegacyHydrateCache = ({
  accessor,
  cache,
  fetchOptions
}) => ({ cacheSnapshot, shouldRefetch = false }) => {
  const { cache: snapshot, selections: selectionSnapshots } = parseSnapshot(cacheSnapshot);
  if (snapshot) {
    cache.restore(snapshot);
  }
  if (selectionSnapshots && shouldRefetch) {
    const selections = /* @__PURE__ */ new Set();
    for (const [[root], ...snapshot2] of selectionSnapshots) {
      const { selection } = meta.$meta(
        accessor[root]
      );
      selections.add(selection.fromJSON(snapshot2));
    }
    setTimeout(
      () => {
        resolveSelections.fetchSelections(selections, {
          cache,
          fetchOptions: {
            ...fetchOptions,
            cachePolicy: "no-cache"
            // refetch
          }
        }).then((results) => updateCaches.updateCaches(results, [cache]));
      },
      shouldRefetch === true ? 0 : shouldRefetch
    );
  }
};
const parseSnapshot = (snapshot) => {
  try {
    const data = flatted.fromJSON(snapshot);
    if (!prepareRender.isLegacyCacheSnapshot(data)) {
      throw 1;
    }
    return data;
  } catch {
    throw new index.GQtyError(`Unrecognized snapshot format.`);
  }
};

exports.createLegacyHydrateCache = createLegacyHydrateCache;
exports.parseSnapshot = parseSnapshot;
