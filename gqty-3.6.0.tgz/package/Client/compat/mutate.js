'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const index = require('../../Accessor/index.js');
const index$1 = require('../../Error/index.js');

const createLegacyMutate = ({
  accessor,
  resolvers: { resolve }
}) => async (fn, { onComplete, onError } = {}) => {
  try {
    const data = await resolve(({ mutation }) => fn(mutation), {
      cachePolicy: "no-cache"
    });
    onComplete == null ? void 0 : onComplete(data, {
      query: accessor.query,
      setCache: index.setCache,
      assignSelections: index.assignSelections
    });
    return data;
  } catch (e) {
    if (e instanceof index$1.GQtyError) {
      onError == null ? void 0 : onError(e, {
        query: accessor.query,
        setCache: index.setCache,
        assignSelections: index.assignSelections
      });
    }
    throw e;
  }
};

exports.createLegacyMutate = createLegacyMutate;
