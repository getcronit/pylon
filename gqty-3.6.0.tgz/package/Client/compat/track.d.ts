import type { BaseGeneratedSchema } from '..';
import { GQtyError } from '../../Error';
import type { Selection } from '../../Selection';
import type { CreateLegacyMethodOptions } from './client';
export type LegacyTrackCallType = 'initial' | 'cache_change';
export interface LegacyTrackCallInfo {
    type: LegacyTrackCallType;
}
export interface LegacyTrackOptions {
    onError?: ((err: GQtyError) => void) | undefined;
    operationName?: string;
    /** Refetch on initial call */
    refetch?: boolean;
}
export interface LegacyTrack {
    <TData>(callback: (info: LegacyTrackCallInfo) => TData, options?: LegacyTrackOptions): {
        stop: () => void;
        selections: Set<Selection>;
        data: {
            current: TData | undefined;
        };
    };
}
export declare const createLegacyTrack: <TSchema extends BaseGeneratedSchema = BaseGeneratedSchema>({ cache, context: globalContext, resolvers: { createResolver }, subscribeLegacySelections, }: CreateLegacyMethodOptions<TSchema>) => LegacyTrack;
