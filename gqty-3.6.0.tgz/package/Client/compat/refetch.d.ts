import type { BaseGeneratedSchema } from '..';
import type { Selection } from '../../Selection';
import type { CreateLegacyMethodOptions } from './client';
import type { LegacyInlineResolved } from './inlineResolved';
export type LegacyRefetch<TSchema extends BaseGeneratedSchema> = {
    <TData>(fn: (schema: TSchema) => TData): Promise<TData>;
    <TData>(accessor: TData): Promise<TData>;
};
export declare const createRefetch: <TSchema extends BaseGeneratedSchema>({ cache, fetchOptions, inlineResolved, selectionHistory, }: CreateLegacyMethodOptions<TSchema> & {
    /** Valid scalar selections for refetching. */
    selectionHistory: Set<Selection>;
    inlineResolved: LegacyInlineResolved;
}) => LegacyRefetch<TSchema>;
