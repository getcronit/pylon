import { createLegacyHydrateCache } from './hydrateCache.mjs';
import { createLegacyInlineResolved } from './inlineResolved.mjs';
import { createLegacyMutate } from './mutate.mjs';
import { createLegacyPrefetch } from './prefetch.mjs';
import { createLegacyPrepareRender } from './prepareRender.mjs';
import { createRefetch } from './refetch.mjs';
import { createLegacyResolved } from './resolved.mjs';
import { createLegacyTrack } from './track.mjs';

const createLegacyClient = (options) => {
  const selectionHistory = /* @__PURE__ */ new Set();
  options.context.subscribeSelect((select) => {
    selectionHistory.add(select);
  });
  const methodOptions = {
    ...options,
    subscribeLegacySelections(fn) {
      const { context } = options;
      const unsubscribeSelect = context.subscribeSelect(fn);
      const unsubscribeDispose = context.subscribeDispose(unsubscribeSelect);
      return () => {
        unsubscribeDispose();
        unsubscribeSelect();
      };
    }
  };
  const inlineResolved = createLegacyInlineResolved(methodOptions);
  return {
    query: options.accessor.query,
    mutation: options.accessor.mutation,
    subscription: options.accessor.subscription,
    resolved: createLegacyResolved(methodOptions),
    inlineResolved,
    mutate: createLegacyMutate(methodOptions),
    track: createLegacyTrack(methodOptions),
    prefetch: createLegacyPrefetch(methodOptions),
    refetch: createRefetch({
      ...methodOptions,
      selectionHistory,
      inlineResolved
    }),
    prepareRender: createLegacyPrepareRender(methodOptions),
    hydrateCache: createLegacyHydrateCache(methodOptions),
    subscribeLegacySelections: methodOptions.subscribeLegacySelections
  };
};

export { createLegacyClient };
