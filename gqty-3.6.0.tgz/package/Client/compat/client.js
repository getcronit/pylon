'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const hydrateCache = require('./hydrateCache.js');
const inlineResolved = require('./inlineResolved.js');
const mutate = require('./mutate.js');
const prefetch = require('./prefetch.js');
const prepareRender = require('./prepareRender.js');
const refetch = require('./refetch.js');
const resolved = require('./resolved.js');
const track = require('./track.js');

const createLegacyClient = (options) => {
  const selectionHistory = /* @__PURE__ */ new Set();
  options.context.subscribeSelect((select) => {
    selectionHistory.add(select);
  });
  const methodOptions = {
    ...options,
    subscribeLegacySelections(fn) {
      const { context } = options;
      const unsubscribeSelect = context.subscribeSelect(fn);
      const unsubscribeDispose = context.subscribeDispose(unsubscribeSelect);
      return () => {
        unsubscribeDispose();
        unsubscribeSelect();
      };
    }
  };
  const inlineResolved$1 = inlineResolved.createLegacyInlineResolved(methodOptions);
  return {
    query: options.accessor.query,
    mutation: options.accessor.mutation,
    subscription: options.accessor.subscription,
    resolved: resolved.createLegacyResolved(methodOptions),
    inlineResolved: inlineResolved$1,
    mutate: mutate.createLegacyMutate(methodOptions),
    track: track.createLegacyTrack(methodOptions),
    prefetch: prefetch.createLegacyPrefetch(methodOptions),
    refetch: refetch.createRefetch({
      ...methodOptions,
      selectionHistory,
      inlineResolved: inlineResolved$1
    }),
    prepareRender: prepareRender.createLegacyPrepareRender(methodOptions),
    hydrateCache: hydrateCache.createLegacyHydrateCache(methodOptions),
    subscribeLegacySelections: methodOptions.subscribeLegacySelections
  };
};

exports.createLegacyClient = createLegacyClient;
