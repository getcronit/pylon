import type { BaseGeneratedSchema } from '../..';
import type { CreateLegacyMethodOptions } from './client';
export type LegacyPrefetch<TSchema extends BaseGeneratedSchema> = {
    <TData>(fn: (query: TSchema['query']) => TData): TData | Promise<TData>;
};
export declare const createLegacyPrefetch: <TSchema extends BaseGeneratedSchema = BaseGeneratedSchema>({ resolvers: { createResolver }, subscribeLegacySelections, }: CreateLegacyMethodOptions<TSchema>) => LegacyPrefetch<TSchema>;
