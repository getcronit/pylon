import { GQtyError } from '../../Error/index.mjs';

const createLegacyTrack = ({
  cache,
  context: globalContext,
  resolvers: { createResolver },
  subscribeLegacySelections
}) => {
  const track = (fn, { onError, operationName, refetch = false } = {}) => {
    const trackedSelections = /* @__PURE__ */ new Set();
    const { context, selections, subscribe } = createResolver({
      cachePolicy: refetch ? "no-cache" : "default",
      operationName
    });
    const resolutionCache = refetch ? context.cache : cache;
    const dataFn = (info) => {
      globalContext.cache = resolutionCache;
      try {
        return fn(info);
      } finally {
        globalContext.cache = cache;
      }
    };
    const unsubscribe = subscribeLegacySelections((selection, cache2) => {
      context.select(selection, cache2);
    });
    const data = { current: dataFn({ type: "initial" }) };
    for (const selection of selections) {
      trackedSelections.add(selection);
    }
    context.subscribeSelect((selection) => {
      trackedSelections.add(selection);
    });
    unsubscribe();
    const stop = subscribe({
      onError(error) {
        const theError = GQtyError.create(error);
        if (onError) {
          onError(theError);
        } else {
          throw theError;
        }
      },
      onNext() {
        data.current = dataFn({ type: "cache_change" });
      }
    });
    return { data, selections: trackedSelections, stop };
  };
  return track;
};

export { createLegacyTrack };
