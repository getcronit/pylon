'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const createLegacyQueryFetcher = (queryFetcher) => async ({ query, variables = {} }, fetchOptions) => queryFetcher(query, variables, fetchOptions);

exports.createLegacyQueryFetcher = createLegacyQueryFetcher;
