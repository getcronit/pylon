'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const index = require('../../Error/index.js');
const resolveSelections = require('../resolveSelections.js');
const updateCaches = require('../updateCaches.js');
const selection = require('./selection.js');

const createLegacyResolved = ({
  cache,
  context: globalContext,
  debugger: debug,
  fetchOptions: { fetcher, retryPolicy },
  fetchOptions: clientFetchOptions,
  resolvers: { createResolver },
  subscribeLegacySelections
}) => {
  const resolved = async (fn, {
    fetchOptions,
    noCache = false,
    // prevent cache writes after fetch
    //nonSerializableVariables, // Ignored since our hasher can handle files
    onCacheData,
    onEmptyResolve,
    onNoCacheFound,
    onSelection,
    onSubscription,
    operationName,
    refetch = false,
    // prevent cache reads from selections
    retry = retryPolicy
  } = {}) => {
    const { context, selections } = createResolver({
      cachePolicy: noCache ? "no-store" : refetch ? "no-cache" : "default",
      operationName
    });
    const unsubscribe = subscribeLegacySelections((selection$1, cache2) => {
      context.select(selection$1, cache2);
      onSelection == null ? void 0 : onSelection(selection.convertSelection(selection$1));
    });
    const resolutionCache = refetch ? cache : context.cache;
    const targetCaches = noCache ? [context.cache] : refetch ? [context.cache, cache] : [cache];
    const dataFn = () => {
      globalContext.cache = resolutionCache;
      try {
        return fn();
      } finally {
        globalContext.cache = cache;
      }
    };
    context.shouldFetch || (context.shouldFetch = noCache || refetch);
    const data = dataFn();
    unsubscribe();
    if (selections.size === 0) {
      if (onEmptyResolve) {
        onEmptyResolve();
      } else if (process.env.NODE_ENV !== "production") {
        console.warn("[gqty] Warning! No data requested.");
      }
      return data;
    }
    if (!context.shouldFetch) {
      return data;
    }
    if (context.hasCacheHit) {
      if ((onCacheData == null ? void 0 : onCacheData(data)) === false) {
        return data;
      }
    } else {
      onNoCacheFound == null ? void 0 : onNoCacheFound();
    }
    {
      const unsubscribe2 = resolveSelections.subscribeSelections(
        new Set([...selections].filter((s) => s.root.key === "subscription")),
        ({ data: data2, error, extensions }) => {
          var _a, _b, _c;
          if (data2) {
            updateCaches.updateCaches([{ data: data2, extensions }], targetCaches);
          }
          if (error) {
            onSubscription == null ? void 0 : onSubscription({
              type: "with-errors",
              unsubscribe: async () => unsubscribe2(),
              data: (_b = (_a = dataFn()) != null ? _a : data2) != null ? _b : void 0,
              error: index.GQtyError.create(error)
            });
          } else if (data2) {
            onSubscription == null ? void 0 : onSubscription({
              type: "data",
              unsubscribe: async () => unsubscribe2(),
              data: (_c = dataFn()) != null ? _c : data2
            });
          }
        },
        {
          cache,
          debugger: debug,
          fetchOptions: clientFetchOptions,
          operationName,
          onSubscribe() {
            onSubscription == null ? void 0 : onSubscription({
              type: "start",
              unsubscribe: async () => unsubscribe2()
            });
          },
          onComplete() {
            onSubscription == null ? void 0 : onSubscription({
              type: "complete",
              unsubscribe: async () => unsubscribe2()
            });
          }
        }
      );
    }
    await resolveSelections.fetchSelections(
      new Set([...selections].filter((s) => s.root.key !== "subscription")),
      {
        debugger: debug,
        fetchOptions: { fetcher, retryPolicy: retry, ...fetchOptions },
        operationName
      }
    ).then(
      (results) => updateCaches.updateCaches(results, targetCaches),
      (error) => Promise.reject(index.GQtyError.create(error))
    );
    return dataFn();
  };
  return resolved;
};

exports.createLegacyResolved = createLegacyResolved;
