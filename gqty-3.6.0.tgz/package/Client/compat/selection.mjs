var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var LegacySelectionType = /* @__PURE__ */ ((LegacySelectionType2) => {
  LegacySelectionType2[LegacySelectionType2["Query"] = 0] = "Query";
  LegacySelectionType2[LegacySelectionType2["Mutation"] = 1] = "Mutation";
  LegacySelectionType2[LegacySelectionType2["Subscription"] = 2] = "Subscription";
  return LegacySelectionType2;
})(LegacySelectionType || {});
class LegacySelection {
  constructor({
    key,
    prevSelection,
    args,
    argTypes,
    type,
    operationName,
    alias,
    unions,
    id
  }) {
    __publicField(this, "id");
    __publicField(this, "key");
    __publicField(this, "type");
    __publicField(this, "operationName");
    __publicField(this, "unions");
    __publicField(this, "args");
    __publicField(this, "argTypes");
    __publicField(this, "alias");
    __publicField(this, "cachePath", []);
    __publicField(this, "pathString");
    __publicField(this, "selectionsList");
    __publicField(this, "noIndexSelections");
    __publicField(this, "prevSelection", null);
    __publicField(this, "currentCofetchSelections", null);
    var _a, _b, _c, _d, _e, _f;
    this.id = id + "";
    this.key = key;
    this.operationName = operationName;
    this.prevSelection = prevSelection != null ? prevSelection : null;
    const pathKey = alias || key;
    const isInterfaceUnionSelection = key === "$on";
    this.cachePath = isInterfaceUnionSelection ? (_a = prevSelection == null ? void 0 : prevSelection.cachePath) != null ? _a : [] : prevSelection ? [...prevSelection.cachePath, pathKey] : [pathKey];
    this.pathString = isInterfaceUnionSelection ? (_b = prevSelection == null ? void 0 : prevSelection.pathString) != null ? _b : "" : `${(_c = prevSelection == null ? void 0 : prevSelection.pathString.concat(".")) != null ? _c : ""}${pathKey}`;
    const prevSelectionsList = (_d = prevSelection == null ? void 0 : prevSelection.selectionsList) != null ? _d : [];
    this.selectionsList = [...prevSelectionsList, this];
    const prevNoSelectionsList = (_e = prevSelection == null ? void 0 : prevSelection.noIndexSelections) != null ? _e : [];
    this.noIndexSelections = typeof key === "string" ? [...prevNoSelectionsList, this] : prevNoSelectionsList;
    if (this.selectionsList.length === this.noIndexSelections.length) {
      this.noIndexSelections = this.selectionsList;
    }
    this.alias = alias;
    this.args = args;
    this.argTypes = argTypes;
    this.unions = unions;
    this.type = (_f = type != null ? type : prevSelection == null ? void 0 : prevSelection.type) != null ? _f : 0 /* Query */;
  }
  addCofetchSelections(selections) {
    const cofetchSet = this.currentCofetchSelections || (this.currentCofetchSelections = /* @__PURE__ */ new Set());
    for (const selection of selections) {
      cofetchSet.add(selection);
    }
  }
  get cofetchSelections() {
    let currentPrevSelection = this.prevSelection;
    while (currentPrevSelection) {
      const currentPrevCofetchSelections = currentPrevSelection.currentCofetchSelections;
      if (currentPrevCofetchSelections) {
        this.addCofetchSelections(currentPrevCofetchSelections);
      }
      currentPrevSelection = currentPrevSelection.prevSelection;
    }
    return this.currentCofetchSelections;
  }
}
const convertSelection = (selection, selectionId = 0, operationName) => {
  var _a, _b;
  return new LegacySelection({
    id: ++selectionId,
    key: selection.key,
    // translate the whole selection chain upwards
    prevSelection: selection.parent ? convertSelection(selection.parent, selectionId, operationName) : void 0,
    args: (_a = selection.input) == null ? void 0 : _a.values,
    argTypes: (_b = selection.input) == null ? void 0 : _b.types,
    type: selection.root.key === "query" ? 0 /* Query */ : selection.root.key === "mutation" ? 1 /* Mutation */ : 2 /* Subscription */,
    operationName,
    alias: selection.alias,
    unions: selection.isUnion ? [selection.key.toString()] : void 0
  });
};

export { LegacySelection, LegacySelectionType, convertSelection };
