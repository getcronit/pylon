import type { BaseGeneratedSchema } from '..';
import type { CacheSnapshot } from '../../Cache/persistence';
import type { SelectionSnapshot } from '../../Selection';
import type { CreateLegacyMethodOptions } from './client';
export interface LegacyPrepareRender {
    (render: () => Promise<void> | void): Promise<{
        cacheSnapshot: string;
    }>;
}
export type LegacyCacheSnapshot = {
    cache?: CacheSnapshot;
    selections?: SelectionSnapshot[];
};
export declare const isLegacyCacheSnapshot: (json: unknown) => json is LegacyCacheSnapshot;
export declare const createLegacyPrepareRender: <TSchema extends BaseGeneratedSchema>({ cache, debugger: debug, fetchOptions, subscribeLegacySelections, }: CreateLegacyMethodOptions<TSchema>) => LegacyPrepareRender;
