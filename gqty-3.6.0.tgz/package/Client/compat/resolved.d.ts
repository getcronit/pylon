import type { BaseGeneratedSchema } from '..';
import { GQtyError, type RetryOptions } from '../../Error';
import type { CreateLegacyMethodOptions } from './client';
import { type LegacySelection } from './selection';
export type LegacyFetchOptions = Omit<RequestInit, 'body'>;
export interface LegacyResolved {
    <T = unknown>(fn: () => T, opts?: LegacyResolveOptions<T>): Promise<T>;
}
export interface LegacyResolveOptions<TData> {
    /**
     * Ignore cache data during selection, which always results in a fetch.
     */
    refetch?: boolean;
    /**
     * Do not update the cache after fetch, return the result only.
     */
    noCache?: boolean;
    /**
     * Activate special handling of non-serializable variables,
     * for example, files uploading
     *
     * @default false
     */
    nonSerializableVariables?: boolean;
    /**
     * Middleware function that is called if valid cache is found
     * for all the data requirements, it should return `true` if the
     * the resolution and fetch should continue, and `false`
     * if you wish to stop the resolution, resolving the promise
     * with the existing cache data.
     */
    onCacheData?: (data: TData) => boolean;
    /**
     * On No Cache found
     */
    onNoCacheFound?: () => void;
    /**
     * Get every selection intercepted in the specified function
     */
    onSelection?: (selection: LegacySelection) => void;
    /**
     * On subscription event listener
     */
    onSubscription?: (event: {
        type: 'data';
        unsubscribe: () => Promise<void>;
        data: TData;
        error?: undefined;
    } | {
        type: 'with-errors';
        unsubscribe: () => Promise<void>;
        data?: TData;
        error: GQtyError;
    } | {
        type: 'start' | 'complete';
        unsubscribe: () => Promise<void>;
        data?: undefined;
        error?: undefined;
    }) => void;
    /**
     * Function called on empty resolution
     */
    onEmptyResolve?: () => void;
    /**
     * Retry strategy
     */
    retry?: RetryOptions;
    /**
     * Pass any extra fetch options
     */
    fetchOptions?: LegacyFetchOptions;
    /**
     * Query operation name
     */
    operationName?: string;
}
/**
 * `resolved()` has to be re-implemented from the parts because the new
 * `resolve()` closes subscriptions on first data to mimic a one-time promise,
 * while `resolved()` exposes callbacks, letting subcriptions outlive the
 * promise.
 */
export declare const createLegacyResolved: <TSchema extends BaseGeneratedSchema = BaseGeneratedSchema>({ cache, context: globalContext, debugger: debug, fetchOptions: { fetcher, retryPolicy }, fetchOptions: clientFetchOptions, resolvers: { createResolver }, subscribeLegacySelections, }: CreateLegacyMethodOptions<TSchema>) => LegacyResolved;
