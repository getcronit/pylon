import type { BaseGeneratedSchema } from '..';
import type { CreateLegacyMethodOptions } from './client';
export type LegacyHydrateCache = {
    ({ cacheSnapshot, shouldRefetch }: LegacyHydrateCacheOptions): void;
};
export type LegacyHydrateCacheOptions = {
    /**
     * Cache snapshot, returned from `prepareRender`
     */
    cacheSnapshot: string;
    /**
     * If it should refetch everything after
     *
     * Specify a number greater than `0` to delay the refetch that amount in ms
     *
     * @default
     * false
     */
    shouldRefetch?: boolean | number;
};
export declare const createLegacyHydrateCache: <TSchema extends BaseGeneratedSchema>({ accessor, cache, fetchOptions, }: CreateLegacyMethodOptions<TSchema>) => LegacyHydrateCache;
export declare const parseSnapshot: (snapshot: string) => import("./prepareRender").LegacyCacheSnapshot;
