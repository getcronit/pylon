'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const selection = require('./selection.js');

const createLegacyInlineResolved = ({
  resolvers: { createResolver },
  subscribeLegacySelections
}) => {
  return (fn, {
    refetch = false,
    onEmptyResolve,
    onSelection,
    onCacheData,
    operationName
  } = {}) => {
    const { context, selections, resolve } = createResolver({
      cachePolicy: refetch ? "no-cache" : "default",
      operationName
    });
    const unsubscribe = subscribeLegacySelections((selection$1, cache) => {
      context.select(selection$1, cache);
      onSelection == null ? void 0 : onSelection(selection.convertSelection(selection$1));
    });
    context.shouldFetch || (context.shouldFetch = refetch);
    const data = fn();
    unsubscribe();
    if (selections.size === 0) {
      if (onEmptyResolve) {
        onEmptyResolve();
      } else if (process.env.NODE_ENV !== "production") {
        console.warn("[gqty] Warning! No data requested.");
      }
      return data;
    }
    if (!context.shouldFetch) {
      return data;
    }
    if (context.hasCacheHit && !refetch) {
      onCacheData == null ? void 0 : onCacheData(data);
    }
    return resolve().then(() => fn());
  };
};

exports.createLegacyInlineResolved = createLegacyInlineResolved;
