const createLegacyPrefetch = ({
  resolvers: { createResolver },
  subscribeLegacySelections
}) => (fn, { operationName } = {}) => {
  const {
    accessor: { query },
    context,
    resolve
  } = createResolver({ operationName });
  const unsubscribe = subscribeLegacySelections((selection, cache) => {
    context.select(selection, cache);
  });
  const data = fn(query);
  unsubscribe();
  if (!context.shouldFetch) {
    return data;
  }
  return resolve().then(() => fn(query));
};

export { createLegacyPrefetch };
