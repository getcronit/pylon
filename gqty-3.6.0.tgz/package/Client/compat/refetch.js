'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('../../Utils/hash.js');
const meta = require('../../Accessor/meta.js');
require('../../Accessor/resolve.js');
const resolveSelections = require('../resolveSelections.js');
const updateCaches = require('../updateCaches.js');

const createRefetch = ({
  cache,
  fetchOptions,
  inlineResolved,
  selectionHistory
}) => {
  return async (fnOrProxy, operationName) => {
    var _a;
    if (typeof fnOrProxy === "function") {
      return inlineResolved(fnOrProxy, { refetch: true });
    } else {
      const selection = (_a = meta.$meta(fnOrProxy)) == null ? void 0 : _a.selection;
      if (!selection) {
        if (process.env.NODE_ENV !== "production") {
          console.warn("[gqty] Invalid proxy to refetch!");
        }
        return fnOrProxy;
      }
      const selections = /* @__PURE__ */ new Set();
      for (const leaf of selection.getLeafNodes()) {
        if (selectionHistory.has(leaf)) {
          selections.add(leaf);
        }
      }
      if (selections.size > 0) {
        await resolveSelections.fetchSelections(selections, {
          cache,
          fetchOptions,
          operationName
        }).then((results) => {
          updateCaches.updateCaches(results, [cache]);
        });
      }
      return fnOrProxy;
    }
  };
};

exports.createRefetch = createRefetch;
