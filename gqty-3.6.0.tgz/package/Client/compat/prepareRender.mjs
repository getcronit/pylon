import { toJSON } from 'flatted';
import { isSkeleton } from '../../Accessor/skeleton.mjs';
import { Cache } from '../../Cache/index.mjs';
import '../../Utils/hash.mjs';
import { isPlainObject } from '../../Utils/object.mjs';
import { fetchSelections } from '../resolveSelections.mjs';
import { updateCaches } from '../updateCaches.mjs';

const isLegacyCacheSnapshot = (json) => {
  if (json != null && !isPlainObject(json)) {
    return false;
  }
  const snapshot = json;
  if (snapshot.cache !== void 0 && !isPlainObject(snapshot.cache)) {
    return false;
  }
  if (snapshot.selections) {
    if (!Array.isArray(snapshot.selections)) {
      return false;
    }
    if (!snapshot.selections.every((selection) => {
      if (!Array.isArray(selection) || !selection.every((it) => {
        if (!Array.isArray(it)) return false;
        if (typeof it[0] !== "string" && typeof it[0] !== "number")
          return false;
        if (it[1] && (!isPlainObject(it[1]) || !isPlainObject(it[1].input) || it[1].isUnion !== void 0 && it[1].isUnion !== true))
          return false;
        return true;
      }))
        return false;
      return true;
    }))
      return false;
  }
  return true;
};
const createLegacyPrepareRender = ({
  cache,
  debugger: debug,
  fetchOptions,
  subscribeLegacySelections
}) => {
  return async (render) => {
    const ssrCache = new Cache();
    const selections = /* @__PURE__ */ new Set();
    const unsubscribe = subscribeLegacySelections((selection) => {
      selections.add(selection);
    });
    try {
      await render();
    } finally {
      unsubscribe();
    }
    await fetchSelections(
      new Set(
        [...selections].filter((s) => {
          if (s.root.key === "subscription") return false;
          const cacheKey = s.cacheKeys.join(".");
          const dataContainer = cache.get(cacheKey);
          const data = dataContainer == null ? void 0 : dataContainer.data;
          const hasMissing = (val) => {
            if (val === void 0 || isSkeleton(val)) return true;
            if (Array.isArray(val)) return val.some(hasMissing);
            return false;
          };
          return hasMissing(data);
        })
      ),
      {
        cache,
        debugger: debug,
        fetchOptions
      }
    ).then(
      (results) => updateCaches(results, [cache, ssrCache], { skipNotify: true })
    );
    return {
      cacheSnapshot: toJSON(
        Object.keys(cache.toJSON()).length > 0 ? selections.size > 0 ? { cache, selections: [...selections] } : { cache } : {}
      )
    };
  };
};

export { createLegacyPrepareRender, isLegacyCacheSnapshot };
