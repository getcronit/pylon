import '../../Utils/hash.mjs';
import { $meta } from '../../Accessor/meta.mjs';
import '../../Accessor/resolve.mjs';
import { fetchSelections } from '../resolveSelections.mjs';
import { updateCaches } from '../updateCaches.mjs';

const createRefetch = ({
  cache,
  fetchOptions,
  inlineResolved,
  selectionHistory
}) => {
  return async (fnOrProxy, operationName) => {
    var _a;
    if (typeof fnOrProxy === "function") {
      return inlineResolved(fnOrProxy, { refetch: true });
    } else {
      const selection = (_a = $meta(fnOrProxy)) == null ? void 0 : _a.selection;
      if (!selection) {
        if (process.env.NODE_ENV !== "production") {
          console.warn("[gqty] Invalid proxy to refetch!");
        }
        return fnOrProxy;
      }
      const selections = /* @__PURE__ */ new Set();
      for (const leaf of selection.getLeafNodes()) {
        if (selectionHistory.has(leaf)) {
          selections.add(leaf);
        }
      }
      if (selections.size > 0) {
        await fetchSelections(selections, {
          cache,
          fetchOptions,
          operationName
        }).then((results) => {
          updateCaches(results, [cache]);
        });
      }
      return fnOrProxy;
    }
  };
};

export { createRefetch };
