import type { Selection } from '../../Selection';
export declare enum LegacySelectionType {
    Query = 0,
    Mutation = 1,
    Subscription = 2
}
export type LegacySelectionConstructorArgs = {
    id: number;
    key: string | number;
    prevSelection?: LegacySelection;
    type?: LegacySelectionType;
    operationName?: string;
    alias?: string;
    args?: Record<string, unknown>;
    argTypes?: Record<string, string>;
    unions?: string[];
};
export declare class LegacySelection {
    id: string;
    key: string | number;
    type: LegacySelectionType;
    operationName?: string;
    unions?: string[];
    args?: Readonly<Record<string, unknown>>;
    argTypes?: Readonly<Record<string, string>>;
    alias?: string;
    cachePath: readonly (string | number)[];
    pathString: string;
    selectionsList: readonly LegacySelection[];
    noIndexSelections: readonly LegacySelection[];
    prevSelection: LegacySelection | null;
    currentCofetchSelections: Set<LegacySelection> | null;
    constructor({ key, prevSelection, args, argTypes, type, operationName, alias, unions, id, }: LegacySelectionConstructorArgs);
    addCofetchSelections(selections: LegacySelection[] | Set<LegacySelection>): void;
    get cofetchSelections(): Set<LegacySelection> | null;
}
export declare const convertSelection: (selection: Selection, selectionId?: number, operationName?: string) => LegacySelection;
