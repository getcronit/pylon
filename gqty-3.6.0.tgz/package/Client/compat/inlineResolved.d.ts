import type { BaseGeneratedSchema } from '../..';
import type { CreateLegacyMethodOptions } from './client';
import { type LegacySelection } from './selection';
export interface LegacyInlineResolved {
    <TData = unknown>(fn: () => TData, options?: LegacyInlineResolveOptions<TData>): TData | Promise<TData>;
}
export interface LegacyInlineResolveOptions<TData> {
    refetch?: boolean;
    onEmptyResolve?: () => void;
    /**
     * Get every selection intercepted in the specified function
     */
    onSelection?: (selection: LegacySelection) => void;
    /**
     * On valid cache data found callback
     */
    onCacheData?: (data: TData) => void;
    /**
     * Query operation name
     */
    operationName?: string;
}
export declare const createLegacyInlineResolved: <TSchema extends BaseGeneratedSchema = BaseGeneratedSchema>({ resolvers: { createResolver }, subscribeLegacySelections, }: CreateLegacyMethodOptions<TSchema>) => LegacyInlineResolved;
