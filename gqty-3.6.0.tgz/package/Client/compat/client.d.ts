import type { BaseGeneratedSchema, FetchOptions, SchemaContext } from '../..';
import type { Cache } from '../../Cache';
import type { ScalarsEnumsHash, Schema } from '../../Schema';
import type { Selectable } from '../../Selectable';
import type { createDebugger } from '../debugger';
import type { Resolvers } from '../resolvers';
import { type LegacyHydrateCache } from './hydrateCache';
import { type LegacyInlineResolved } from './inlineResolved';
import { type LegacyMutate } from './mutate';
import { type LegacyPrefetch } from './prefetch';
import { type LegacyPrepareRender } from './prepareRender';
import type { LegacyQueryFetcher } from './queryFetcher';
import { type LegacyRefetch } from './refetch';
import { type LegacyResolved } from './resolved';
import type { LegacySubscriptionsClient } from './subscriptionsClient';
import { type LegacyTrack } from './track';
export { type LegacyHydrateCache, type LegacyHydrateCacheOptions, } from './hydrateCache';
export { type LegacyInlineResolveOptions, type LegacyInlineResolved, } from './inlineResolved';
export { type LegacyMutate, type LegacyMutateHelpers } from './mutate';
export { type LegacyPrefetch } from './prefetch';
export { type LegacyQueryFetcher } from './queryFetcher';
export { type LegacyRefetch } from './refetch';
export { type LegacyResolveOptions, type LegacyResolved } from './resolved';
export { type LegacySelection } from './selection';
export { type LegacySubscribeEvents, type LegacySubscriptionsClient, } from './subscriptionsClient';
export { type LegacyTrack, type LegacyTrackCallInfo, type LegacyTrackCallType, type LegacyTrackOptions, } from './track';
export type CreateLegacyClientOptions<TSchema extends BaseGeneratedSchema> = {
    accessor: TSchema;
    cache: Cache;
    context: SchemaContext;
    debugger: ReturnType<typeof createDebugger>;
    fetchOptions: FetchOptions;
    resolvers: Resolvers<TSchema>;
    scalars: ScalarsEnumsHash;
    schema: Readonly<Schema>;
    __depthLimit?: number;
};
export type LegacyClientOptions = {
    queryFetcher?: LegacyQueryFetcher;
    scalarsEnumsHash?: ScalarsEnumsHash;
    subscriptionsClient?: LegacySubscriptionsClient;
};
/**
 * Subscribing to selections made by global accessors, exposed for testing
 * purpose.
 */
export type SelectionSubscriber = (fn: Selectable['select']) => () => void;
export type LegacyClient<TSchema extends BaseGeneratedSchema> = {
    /**
     * @deprecated Use the new `resolve()` method.
     */
    resolved: LegacyResolved;
    /**
     * @deprecated Use the new `resolve()` method.
     */
    inlineResolved: LegacyInlineResolved;
    /**
     * @deprecated Use the new `resolve()` method.
     */
    mutate: LegacyMutate<TSchema>;
    /**
     * @deprecated Use the new `subscribe()` method.
     */
    track: LegacyTrack;
    /**
     * @deprecated Use the new `resolve()` method.
     */
    prefetch: LegacyPrefetch<TSchema>;
    /**
     * @deprecated Use the new `resolve()` method.
     */
    refetch: LegacyRefetch<TSchema>;
    /**
     * Captures selections made with a fake render, fetches them and returns the
     * result.
     */
    prepareRender: LegacyPrepareRender;
    /**
     * @deprecated The new cache hydration has no `shouldRefetch` option. It
     * always skip `no-cache` and `no-store` queries, and refetches according
     * to cache expiry.
     */
    hydrateCache: LegacyHydrateCache;
    /**
     * @deprecated Please migrate from global accessors to locally scoped
     * accessors, i.e. `resolve({ query } => {})` or
     * `subscribe({ query } => {})`.
     */
    query: TSchema['query'];
    /**
     * @deprecated Please migrate from global accessors to locally scoped
     * accessors, i.e. `resolve({ mutation } => {})` or
     * `subscribe({ mutation } => {})`.
     */
    mutation: TSchema['mutation'];
    /**
     * @deprecated Please migrate from global accessors to locally scoped
     * accessors, i.e. `resolve({ subscription } => {})` or
     * `subscribe({ subscription } => {})`.
     */
    subscription: TSchema['subscription'];
    /** Exposed for testing purpose. */
    subscribeLegacySelections: SelectionSubscriber;
};
export type CreateLegacyMethodOptions<TSchema extends BaseGeneratedSchema> = CreateLegacyClientOptions<TSchema> & {
    subscribeLegacySelections: SelectionSubscriber;
};
export declare const createLegacyClient: <TSchema extends BaseGeneratedSchema>(options: CreateLegacyClientOptions<TSchema>) => LegacyClient<TSchema>;
