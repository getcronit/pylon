import { GQtyError } from '../../Error/index.mjs';
import { subscribeSelections, fetchSelections } from '../resolveSelections.mjs';
import { updateCaches } from '../updateCaches.mjs';
import { convertSelection } from './selection.mjs';

const createLegacyResolved = ({
  cache,
  context: globalContext,
  debugger: debug,
  fetchOptions: { fetcher, retryPolicy },
  fetchOptions: clientFetchOptions,
  resolvers: { createResolver },
  subscribeLegacySelections
}) => {
  const resolved = async (fn, {
    fetchOptions,
    noCache = false,
    // prevent cache writes after fetch
    //nonSerializableVariables, // Ignored since our hasher can handle files
    onCacheData,
    onEmptyResolve,
    onNoCacheFound,
    onSelection,
    onSubscription,
    operationName,
    refetch = false,
    // prevent cache reads from selections
    retry = retryPolicy
  } = {}) => {
    const { context, selections } = createResolver({
      cachePolicy: noCache ? "no-store" : refetch ? "no-cache" : "default",
      operationName
    });
    const unsubscribe = subscribeLegacySelections((selection, cache2) => {
      context.select(selection, cache2);
      onSelection == null ? void 0 : onSelection(convertSelection(selection));
    });
    const resolutionCache = refetch ? cache : context.cache;
    const targetCaches = noCache ? [context.cache] : refetch ? [context.cache, cache] : [cache];
    const dataFn = () => {
      globalContext.cache = resolutionCache;
      try {
        return fn();
      } finally {
        globalContext.cache = cache;
      }
    };
    context.shouldFetch || (context.shouldFetch = noCache || refetch);
    const data = dataFn();
    unsubscribe();
    if (selections.size === 0) {
      if (onEmptyResolve) {
        onEmptyResolve();
      } else if (process.env.NODE_ENV !== "production") {
        console.warn("[gqty] Warning! No data requested.");
      }
      return data;
    }
    if (!context.shouldFetch) {
      return data;
    }
    if (context.hasCacheHit) {
      if ((onCacheData == null ? void 0 : onCacheData(data)) === false) {
        return data;
      }
    } else {
      onNoCacheFound == null ? void 0 : onNoCacheFound();
    }
    {
      const unsubscribe2 = subscribeSelections(
        new Set([...selections].filter((s) => s.root.key === "subscription")),
        ({ data: data2, error, extensions }) => {
          var _a, _b, _c;
          if (data2) {
            updateCaches([{ data: data2, extensions }], targetCaches);
          }
          if (error) {
            onSubscription == null ? void 0 : onSubscription({
              type: "with-errors",
              unsubscribe: async () => unsubscribe2(),
              data: (_b = (_a = dataFn()) != null ? _a : data2) != null ? _b : void 0,
              error: GQtyError.create(error)
            });
          } else if (data2) {
            onSubscription == null ? void 0 : onSubscription({
              type: "data",
              unsubscribe: async () => unsubscribe2(),
              data: (_c = dataFn()) != null ? _c : data2
            });
          }
        },
        {
          cache,
          debugger: debug,
          fetchOptions: clientFetchOptions,
          operationName,
          onSubscribe() {
            onSubscription == null ? void 0 : onSubscription({
              type: "start",
              unsubscribe: async () => unsubscribe2()
            });
          },
          onComplete() {
            onSubscription == null ? void 0 : onSubscription({
              type: "complete",
              unsubscribe: async () => unsubscribe2()
            });
          }
        }
      );
    }
    await fetchSelections(
      new Set([...selections].filter((s) => s.root.key !== "subscription")),
      {
        debugger: debug,
        fetchOptions: { fetcher, retryPolicy: retry, ...fetchOptions },
        operationName
      }
    ).then(
      (results) => updateCaches(results, targetCaches),
      (error) => Promise.reject(GQtyError.create(error))
    );
    return dataFn();
  };
  return resolved;
};

export { createLegacyResolved };
