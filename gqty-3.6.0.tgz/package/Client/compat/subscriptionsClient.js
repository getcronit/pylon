'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const index = require('../../Error/index.js');
const deferred = require('../../Utils/deferred.js');

const createLegacySubscriptionsClient = (subscriptionsClient) => {
  const listeners = /* @__PURE__ */ new Map();
  const dispatchEvent = (event, ...args) => {
    const listenersSet = listeners.get(event);
    if (listenersSet) {
      for (const listener of listenersSet) {
        listener(...args);
      }
    }
  };
  const client = {
    subscribe: (payload, sink) => {
      var _a;
      const maybePromise = subscriptionsClient.subscribe({
        query: payload.query,
        variables: (_a = payload.variables) != null ? _a : {},
        selections: [],
        events: {
          onStart: () => {
            dispatchEvent("message", {
              type: "connection_ack"
            });
          },
          onComplete: () => {
            sink.complete();
          },
          onData: (data) => {
            sink.next({
              data
            });
          },
          onError({ data, error }) {
            var _a2, _b;
            if (error && !((_a2 = error.graphQLErrors) == null ? void 0 : _a2.length) || !data) {
              sink.error((_b = error.otherError) != null ? _b : error);
            } else {
              sink.next({
                data,
                errors: error.graphQLErrors
              });
            }
          }
        }
      });
      let unsubscribe;
      if (maybePromise instanceof Promise) {
        maybePromise.then(({ operationId, unsubscribe: _unsubscribe }) => {
          unsubscribe = _unsubscribe;
          dispatchEvent("message", {
            id: operationId,
            type: "subscribe",
            payload
          });
        });
      } else {
        const sub = maybePromise;
        unsubscribe = sub.unsubscribe;
        dispatchEvent("message", {
          id: sub.operationId,
          type: "subscribe",
          payload
        });
      }
      return () => {
        if (unsubscribe === void 0) {
          throw new index.GQtyError(`Subscription has not started yet.`);
        }
        unsubscribe();
        sink.complete();
      };
    },
    iterate(payload) {
      const observable = deferred.createDeferredIterator();
      const unsub = this.subscribe(payload, {
        next: observable.send,
        error: observable.throw,
        complete: observable.complete
      });
      return {
        next: observable.next,
        return: () => {
          unsub();
          return observable.return();
        },
        throw: (error) => {
          unsub();
          return observable.throw(error);
        },
        [Symbol.asyncIterator]() {
          return this;
        }
      };
    },
    dispose: () => {
      subscriptionsClient.close();
    },
    terminate: () => {
      subscriptionsClient.close();
    },
    on(event, listener) {
      var _a;
      const untypedListener = listener;
      const listenersSet = (_a = listeners.get(event)) != null ? _a : /* @__PURE__ */ new Set();
      listenersSet.add(untypedListener);
      listeners.set(event, listenersSet);
      return () => {
        listenersSet.delete(untypedListener);
      };
    }
  };
  return client;
};

exports.createLegacySubscriptionsClient = createLegacySubscriptionsClient;
