const createLegacyQueryFetcher = (queryFetcher) => async ({ query, variables = {} }, fetchOptions) => queryFetcher(query, variables, fetchOptions);

export { createLegacyQueryFetcher };
