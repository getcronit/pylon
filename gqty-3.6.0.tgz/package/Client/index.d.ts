import type { Client as SseClient } from 'graphql-sse';
import type { Client as WsClient } from 'graphql-ws';
import { Cache } from '../Cache';
import { type Persistors } from '../Cache/persistence';
import type { RetryOptions } from '../Error';
import type { GeneratedSchemaObject, QueryFetcher, ScalarsEnumsHash, Schema } from '../Schema';
import { type LegacyClient, type LegacyClientOptions } from './compat/client';
import { type Debugger } from './debugger';
import { type Resolvers } from './resolvers';
export { $meta } from '../Accessor';
export { getFields, prepass, selectFields } from '../Helpers';
export * as useMetaStateHack from '../Helpers/useMetaStateHack';
export type { LegacyClientOptions as LegacyFetchers, LegacyHydrateCache, LegacyHydrateCacheOptions, LegacyInlineResolved, LegacyInlineResolveOptions, LegacyMutate, LegacyMutateHelpers, LegacyPrefetch, LegacyQueryFetcher, LegacyRefetch, LegacyResolved, LegacyResolveOptions, LegacySelection, LegacySubscribeEvents, LegacySubscriptionsClient, LegacyTrack, LegacyTrackCallInfo, LegacyTrackCallType, LegacyTrackOptions, } from './compat/client';
export type { SchemaContext } from './context';
export type { DebugEvent } from './debugger';
export { fetchSelections, subscribeSelections } from './resolveSelections';
/** A generated schema type in it's most basic form */
export type BaseGeneratedSchema = {
    query: GeneratedSchemaObject;
    mutation?: GeneratedSchemaObject;
    subscription?: GeneratedSchemaObject;
};
export type SchemaObjectKeys<TSchema extends BaseGeneratedSchema> = Exclude<keyof TSchema, 'query' | 'mutation' | 'subscription' | number | symbol>;
export type SchemaObjects<TSchema extends BaseGeneratedSchema> = {
    [key in SchemaObjectKeys<TSchema>]: {
        __typename: key;
    };
};
export type SubscriptionClient = SseClient | WsClient;
export type FetchOptions = Omit<RequestInit, 'body' | 'mode'> & {
    fetcher: QueryFetcher;
    /**
     * Defines how a query should fetch from the cache and network.
     *
     * - `default`: Serves the cached contents when it is fresh, and if they are
     * stale within `staleWhileRevalidate` window, fetches in the background and
     * updates the cache. Or simply fetches on stale cache or cache miss. During
     * SWR, a successful fetch will not notify cache updates. New contents are
     * served on next query.
     * - `no-store`: Always fetch and does not update on response.
     * GQty creates a temporary cache at query-level which immediately expires.
     * - `reload`: Always fetch, updates on response.
     * - `no-cache`: Same as `reload`, for GraphQL does not support conditional
     * requests.
     * - `force-cache`: Serves the cached contents regardless of staleness. It
     * fetches on cache miss or a stale cache, updates cache on response.
     * - `only-if-cached`: Serves the cached contents regardless of staleness,
     * throws a network error on cache miss.
     *
     * _It takes effort to make sure the above stays true for all supported
     * frameworks, please consider sponsoring so we can dedicate even more time on
     * this._
     */
    cachePolicy?: RequestCache;
    /** Default retry strategy upon fetch failure, configurable on query level. */
    retryPolicy?: RetryOptions;
    /** Client implementation for GraphQL Subscriptions. */
    subscriber?: SubscriptionClient;
};
export type ClientOptions = {
    /**
     * Maximum alias length, reducing overall query payload. You may increase this
     * when collisions occur, specify Infinity here to use the full hash.
     *
     * @default 6
     */
    aliasLength?: number;
    /**
     * Milliseconds to wait before pending queries are batched up for fetching.
     */
    batchWindow?: number;
    /**
     * The cache to be used by the accessors and fetches.
     */
    cache: Cache;
    /**
     * Options related to fetching.
     */
    fetchOptions: FetchOptions;
    scalars: ScalarsEnumsHash;
    /**
     * The generated schema object.
     */
    schema: Readonly<Schema>;
    /**
     * Maximum accessor depth before an error is thrown, prevents infinite
     * recursions.
     *
     * @default 15
     */
    __depthLimit?: number;
};
export type Client<TSchema extends BaseGeneratedSchema> = Persistors & Resolvers<TSchema> & LegacyClient<TSchema> & {
    /** Global cache accessors. */
    schema: TSchema;
    /** Subscribe to debug events, useful for logging. */
    subscribeDebugEvents: Debugger['subscribe'];
    /** Get the cache instance of this client. */
    readonly cache: Cache;
};
export declare const createClient: <TSchema extends BaseGeneratedSchema, _ObjectTypesNames extends string = never, _ObjectTypes extends SchemaObjects<TSchema> = never>({ aliasLength, batchWindow, cache, fetchOptions: { fetcher, cachePolicy: fetchPolicy, retryPolicy: defaultRetryPolicy, subscriber, ...fetchOptions }, scalars, schema, __depthLimit, ...legacyOptions }: ClientOptions & LegacyClientOptions) => Client<TSchema>;
