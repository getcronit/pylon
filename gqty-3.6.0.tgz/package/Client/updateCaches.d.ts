import type { Cache, CacheSetOptions } from '../Cache';
import type { FetchResult } from './resolveSelections';
export declare const updateCaches: <TData extends Record<string, unknown>>(results: Iterable<FetchResult<TData>>, caches: Iterable<Cache>, cacheSetOptions?: CacheSetOptions) => void;
