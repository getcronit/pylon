const isWsClient = (client) => client !== void 0 && typeof client.on === "function";
const createSubscriber = (input) => {
  const client = input;
  if (client.onSubscribe !== void 0) {
    return client;
  }
  const listeners = [];
  client.on("connected", () => {
    if (!client.isOnline) {
      client.isOnline = true;
      listeners.forEach((fn) => fn());
      listeners.length = 0;
    }
  });
  client.on("closed", () => {
    client.isOnline = false;
  });
  client.onSubscribe = (fn) => {
    if (client.isOnline) {
      fn();
    } else {
      listeners.push(fn);
    }
  };
  return client;
};

export { createSubscriber, isWsClient };
