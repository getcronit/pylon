import { createSchemaAccessor } from '../Accessor/index.mjs';
import { Cache } from '../Cache/index.mjs';
import { createPersistors } from '../Cache/persistence.mjs';
import { createLegacyClient } from './compat/client.mjs';
import { createLegacyQueryFetcher } from './compat/queryFetcher.mjs';
import { createLegacySubscriptionsClient } from './compat/subscriptionsClient.mjs';
import { createContext } from './context.mjs';
import { createDebugger } from './debugger.mjs';
import { createResolvers } from './resolvers.mjs';
import 'flatted';
import 'graphql';
export { getFields } from '../Helpers/getFields.mjs';
export { prepass } from '../Helpers/prepass.mjs';
export { selectFields } from '../Helpers/selectFields.mjs';
import * as useMetaStateHack from '../Helpers/useMetaStateHack.mjs';
export { useMetaStateHack };
export { fetchSelections, subscribeSelections } from './resolveSelections.mjs';
export { $meta } from '../Accessor/meta.mjs';

const createClient = ({
  aliasLength = 6,
  batchWindow,
  // This default cache on a required option is for legacy clients, which does
  // not provide a `cache` option.
  // [ ] compat: remove in v4
  cache = new Cache(void 0, { normalization: true }),
  fetchOptions: {
    fetcher,
    cachePolicy: fetchPolicy = "default",
    retryPolicy: defaultRetryPolicy = {
      maxRetries: 3,
      retryDelay: 1e3
    },
    subscriber,
    ...fetchOptions
  } = {},
  scalars,
  schema,
  __depthLimit = 15,
  ...legacyOptions
}) => {
  var _a;
  {
    if (legacyOptions.queryFetcher) {
      fetcher != null ? fetcher : fetcher = createLegacyQueryFetcher(legacyOptions.queryFetcher);
    }
    if (legacyOptions.subscriptionsClient) {
      subscriber != null ? subscriber : subscriber = createLegacySubscriptionsClient(
        legacyOptions.subscriptionsClient
      );
    }
    if (legacyOptions.scalarsEnumsHash) {
      scalars != null ? scalars : scalars = legacyOptions.scalarsEnumsHash;
    }
  }
  const debug = createDebugger();
  const clientContext = createContext({
    aliasLength,
    cache,
    depthLimit: __depthLimit,
    cachePolicy: fetchPolicy,
    scalars,
    schema,
    typeKeys: (_a = cache.normalizationOptions) == null ? void 0 : _a.schemaKeys
  });
  const resolvers = createResolvers({
    aliasLength,
    batchWindow,
    scalars,
    schema,
    cache,
    debugger: debug,
    fetchOptions: {
      fetcher,
      cachePolicy: fetchPolicy,
      retryPolicy: defaultRetryPolicy,
      subscriber,
      ...fetchOptions
    },
    depthLimit: __depthLimit,
    parentContext: clientContext
  });
  const { accessor } = createSchemaAccessor(clientContext);
  return {
    ...resolvers,
    schema: accessor,
    subscribeDebugEvents: debug.subscribe,
    ...createPersistors(cache),
    get cache() {
      return cache;
    },
    ...createLegacyClient({
      accessor,
      cache,
      context: clientContext,
      debugger: debug,
      fetchOptions: {
        fetcher,
        cachePolicy: fetchPolicy,
        retryPolicy: defaultRetryPolicy,
        subscriber,
        ...fetchOptions
      },
      scalars,
      schema,
      resolvers,
      __depthLimit
    })
  };
};

export { createClient };
