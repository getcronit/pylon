import { Cache, type CacheGetOptions } from '../Cache';
import type { Disposable } from '../Disposable';
import type { Resetable } from '../Resetable';
import type { ScalarsEnumsHash, Schema } from '../Schema';
import type { Selectable } from '../Selectable';
export type SchemaContext<T extends Record<string, unknown> = Record<string, unknown>> = T & Disposable & Resetable & Selectable & {
    cache: Cache;
    readonly aliasLength?: number;
    readonly cacheOptions?: CacheGetOptions;
    readonly depthLimit: number;
    readonly scalars: ScalarsEnumsHash;
    /** Root schema for type lookups */
    readonly schema: Readonly<Schema>;
    /** Custom key fields for each object type. */
    readonly typeKeys?: Record<string, string[]>;
    notifyCacheUpdate: boolean;
    shouldFetch: boolean;
    hasCacheHit: boolean;
    /**
     * Useful for identifying SWR fetches where
     * `shouldFetch` is true and `hasCacheHit` is false.
     */
    hasCacheMiss: boolean;
};
export type CreateContextOptions = {
    aliasLength?: number;
    cache: Cache;
    depthLimit: number;
    cachePolicy: RequestCache;
    scalars: ScalarsEnumsHash;
    schema: Readonly<Schema>;
    typeKeys?: Record<string, string[]>;
};
export declare const createContext: ({ aliasLength, cache, cachePolicy, depthLimit, scalars, schema, typeKeys, }: CreateContextOptions) => SchemaContext;
