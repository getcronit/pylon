import type { Client as SseClient } from 'graphql-sse';
import type { Client as WsClient } from 'graphql-ws';
export declare const isWsClient: (client?: SseClient | WsClient) => client is WsClient;
export type GQtyWsClient = WsClient & {
    isOnline?: boolean;
    /**
     * Subscription listeners to be called when the client is online, or called
     * immediately when the client is already online.
     */
    onSubscribe: (fn: () => void) => void;
};
/**
 * Warning: If the WebSocket is already connected before this funciton is
 * called, the `onSubscribe` will not be called until next connected event.
 */
export declare const createSubscriber: (input: WsClient) => GQtyWsClient;
