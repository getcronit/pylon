import extend from 'just-extend';
import { GQtyError } from '../Error/index.mjs';

const updateCaches = (results, caches, cacheSetOptions) => {
  var _a;
  const errorSet = /* @__PURE__ */ new Set();
  for (const response of results) {
    const { data, error, extensions } = response;
    const type = extensions == null ? void 0 : extensions.type;
    if (!type || typeof type !== "string") {
      if (process.env.NODE_ENV !== "production") {
        console.warn("[GQty] Missing extensions.type in query result.");
      }
      continue;
    }
    if (data !== void 0) {
      const newValues = {
        [type]: extend(true, {}, data)
      };
      for (const cache of caches) {
        cache.set(newValues, cacheSetOptions);
      }
    }
    if (error) {
      if (!(error instanceof GQtyError) || !((_a = error.graphQLErrors) == null ? void 0 : _a.length)) {
        throw error;
      } else {
        error.graphQLErrors.forEach((error2) => errorSet.add(error2));
      }
    }
  }
  if (errorSet.size) {
    throw GQtyError.fromGraphQLErrors(Array.from(errorSet));
  }
};

export { updateCaches };
