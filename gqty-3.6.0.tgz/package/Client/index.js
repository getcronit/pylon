'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const index = require('../Accessor/index.js');
const index$1 = require('../Cache/index.js');
const persistence = require('../Cache/persistence.js');
const client = require('./compat/client.js');
const queryFetcher = require('./compat/queryFetcher.js');
const subscriptionsClient = require('./compat/subscriptionsClient.js');
const context = require('./context.js');
const _debugger = require('./debugger.js');
const resolvers = require('./resolvers.js');
require('flatted');
require('graphql');
const getFields = require('../Helpers/getFields.js');
const prepass = require('../Helpers/prepass.js');
const selectFields = require('../Helpers/selectFields.js');
const useMetaStateHack = require('../Helpers/useMetaStateHack.js');
const resolveSelections = require('./resolveSelections.js');
const meta = require('../Accessor/meta.js');

const createClient = ({
  aliasLength = 6,
  batchWindow,
  // This default cache on a required option is for legacy clients, which does
  // not provide a `cache` option.
  // [ ] compat: remove in v4
  cache = new index$1.Cache(void 0, { normalization: true }),
  fetchOptions: {
    fetcher,
    cachePolicy: fetchPolicy = "default",
    retryPolicy: defaultRetryPolicy = {
      maxRetries: 3,
      retryDelay: 1e3
    },
    subscriber,
    ...fetchOptions
  } = {},
  scalars,
  schema,
  __depthLimit = 15,
  ...legacyOptions
}) => {
  var _a;
  {
    if (legacyOptions.queryFetcher) {
      fetcher != null ? fetcher : fetcher = queryFetcher.createLegacyQueryFetcher(legacyOptions.queryFetcher);
    }
    if (legacyOptions.subscriptionsClient) {
      subscriber != null ? subscriber : subscriber = subscriptionsClient.createLegacySubscriptionsClient(
        legacyOptions.subscriptionsClient
      );
    }
    if (legacyOptions.scalarsEnumsHash) {
      scalars != null ? scalars : scalars = legacyOptions.scalarsEnumsHash;
    }
  }
  const debug = _debugger.createDebugger();
  const clientContext = context.createContext({
    aliasLength,
    cache,
    depthLimit: __depthLimit,
    cachePolicy: fetchPolicy,
    scalars,
    schema,
    typeKeys: (_a = cache.normalizationOptions) == null ? void 0 : _a.schemaKeys
  });
  const resolvers$1 = resolvers.createResolvers({
    aliasLength,
    batchWindow,
    scalars,
    schema,
    cache,
    debugger: debug,
    fetchOptions: {
      fetcher,
      cachePolicy: fetchPolicy,
      retryPolicy: defaultRetryPolicy,
      subscriber,
      ...fetchOptions
    },
    depthLimit: __depthLimit,
    parentContext: clientContext
  });
  const { accessor } = index.createSchemaAccessor(clientContext);
  return {
    ...resolvers$1,
    schema: accessor,
    subscribeDebugEvents: debug.subscribe,
    ...persistence.createPersistors(cache),
    get cache() {
      return cache;
    },
    ...client.createLegacyClient({
      accessor,
      cache,
      context: clientContext,
      debugger: debug,
      fetchOptions: {
        fetcher,
        cachePolicy: fetchPolicy,
        retryPolicy: defaultRetryPolicy,
        subscriber,
        ...fetchOptions
      },
      scalars,
      schema,
      resolvers: resolvers$1,
      __depthLimit
    })
  };
};

exports.getFields = getFields.getFields;
exports.prepass = prepass.prepass;
exports.selectFields = selectFields.selectFields;
exports.useMetaStateHack = useMetaStateHack;
exports.fetchSelections = resolveSelections.fetchSelections;
exports.subscribeSelections = resolveSelections.subscribeSelections;
exports.$meta = meta.$meta;
exports.createClient = createClient;
