import type { ExecutionResult } from 'graphql';
import type { Client as SseClient } from 'graphql-sse';
import type { CloseEvent } from 'ws';
import type { FetchOptions } from '.';
import type { Cache } from '../Cache';
import { GQtyError } from '../Error';
import type { Selection } from '../Selection';
import type { Debugger } from './debugger';
import { type GQtyWsClient } from './subscriber';
export type ResolverFetchOptions = Omit<FetchOptions, 'subscriber'> & {
    subscriber?: SseClient | GQtyWsClient;
};
export type FetchSelectionsOptions = {
    cache?: Cache;
    debugger?: Debugger;
    extensions?: Record<string, unknown>;
    fetchOptions: ResolverFetchOptions;
    operationName?: string;
};
export type QueryExtensions = {
    type: string;
    hash: string;
};
export type FetchResult<TData extends Record<string, unknown> = Record<string, unknown>> = Omit<ExecutionResult<TData>, 'errors'> & {
    error?: Error | GQtyError;
};
export declare const fetchSelections: <TData extends Record<string, unknown> = Record<string, unknown>>(selections: Set<Selection>, { cache, debugger: debug, extensions: customExtensions, fetchOptions, operationName, }: FetchSelectionsOptions) => Promise<FetchResult<TData>[]>;
export type SubscribeSelectionOptions = FetchSelectionsOptions & {
    onComplete?: () => void;
    onSubscribe?: () => void;
};
export type SubscriptionCallback<TData extends Record<string, unknown>> = (result: FetchResult<TData>) => void;
export type Unsubscribe = () => void;
export declare const subscribeSelections: <TData extends Record<string, unknown> = Record<string, unknown>>(selections: Set<Selection>, 
/**
 * When a connection closes, this function will be called a last time without
 * any arguments.
 */
fn: SubscriptionCallback<TData>, { cache, debugger: debug, extensions: customExtensions, fetchOptions: { subscriber }, operationName, onSubscribe, onComplete, }: SubscribeSelectionOptions) => Unsubscribe;
export declare const isCloseEvent: (input: unknown) => input is CloseEvent;
