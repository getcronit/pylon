import type { Cache } from '../Cache';
import type { Selection } from '../Selection';
export declare const addSelections: (cache: Cache, key: string, selections: Set<Selection>) => Set<Set<Selection>>;
export declare const getSelectionsSet: (cache: Cache, key: string) => Set<Set<Selection>> | undefined;
export declare const delSelectionSet: (cache: Cache, key: string) => boolean;
export declare const popSelectionsSet: (cache: Cache, key: string) => Set<Set<Selection>> | undefined;
