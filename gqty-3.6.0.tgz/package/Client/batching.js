'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const pendingSelections = /* @__PURE__ */ new Map();
const addSelections = (cache, key, selections) => {
  if (!pendingSelections.has(cache)) {
    pendingSelections.set(cache, /* @__PURE__ */ new Map());
  }
  const selectionsByKey = pendingSelections.get(cache);
  if (!selectionsByKey.has(key)) {
    selectionsByKey.set(key, /* @__PURE__ */ new Set());
  }
  return selectionsByKey.get(key).add(selections);
};
const getSelectionsSet = (cache, key) => {
  var _a;
  return (_a = pendingSelections.get(cache)) == null ? void 0 : _a.get(key);
};
const delSelectionSet = (cache, key) => {
  var _a, _b;
  return (_b = (_a = pendingSelections.get(cache)) == null ? void 0 : _a.delete(key)) != null ? _b : false;
};
const popSelectionsSet = (cache, key) => {
  const result = getSelectionsSet(cache, key);
  delSelectionSet(cache, key);
  return result;
};

exports.addSelections = addSelections;
exports.delSelectionSet = delSelectionSet;
exports.getSelectionsSet = getSelectionsSet;
exports.popSelectionsSet = popSelectionsSet;
