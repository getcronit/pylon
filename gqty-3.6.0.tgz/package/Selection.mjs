import { GQtyError } from './Error/index.mjs';
import { hash } from './Utils/hash.mjs';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
const createSymbol = /* @__PURE__ */ Symbol();
const aliasGenerator = {
  seq: 0,
  map: /* @__PURE__ */ new WeakMap(),
  hash,
  get(key, input) {
    var _a;
    const hash2 = this.hash({ key, ...input });
    if (hash2) return hash2;
    const seq = (_a = this.map.get(input)) != null ? _a : this.seq++;
    if (seq >= Number.MAX_SAFE_INTEGER) {
      throw new GQtyError(`selection alias fallback overflow`);
    }
    this.map.set(input, seq);
    return `alias${seq}`;
  }
};
class Selection {
  constructor(key, options = {}, token) {
    this.key = key;
    this.options = options;
    __publicField(this, "children", /* @__PURE__ */ new Map());
    if (token !== createSymbol) {
      throw new GQtyError(`Use Selection.createRoot() instead.`);
    }
  }
  get alias() {
    return this.options.alias;
  }
  get aliasLength() {
    var _a, _b, _c;
    return (_c = (_b = this.options.aliasLength) != null ? _b : (_a = this.parent) == null ? void 0 : _a.aliasLength) != null ? _c : 6;
  }
  get input() {
    return this.options.input;
  }
  /** Indicates current selection being a inteface/union key. */
  get isUnion() {
    var _a;
    return (_a = this.options.isUnion) != null ? _a : false;
  }
  get parent() {
    return this.options.parent;
  }
  get root() {
    var _a, _b;
    return (_b = (_a = this.options.parent) == null ? void 0 : _a.root) != null ? _b : this;
  }
  get cacheKeys() {
    var _a, _b, _c, _d;
    const keys = (_b = (_a = this.parent) == null ? void 0 : _a.cacheKeys) != null ? _b : [];
    if (typeof this.key === "number" || this.key === "$on" || ((_c = this.parent) == null ? void 0 : _c.key) === "$on") {
      return keys;
    }
    return keys.concat((_d = this.alias) != null ? _d : this.key);
  }
  /** The selection path from root the leaf as an array. */
  get ancestry() {
    const ancestry = [];
    let node = this;
    do {
      ancestry.unshift(node);
    } while (node = node.parent);
    return ancestry;
  }
  static createRoot(key, options) {
    return new Selection(key, options, createSymbol);
  }
  getChild(key, options) {
    var _a, _b, _c;
    const alias = (_b = options == null ? void 0 : options.alias) != null ? _b : (options == null ? void 0 : options.input) ? aliasGenerator.get(key, options.input).slice(0, (_a = options == null ? void 0 : options.aliasLength) != null ? _a : this.aliasLength) : void 0;
    const hashKey = alias != null ? alias : key.toString();
    const selection = (_c = this.children.get(hashKey)) != null ? _c : new Selection(key, { ...options, alias, parent: this }, createSymbol);
    this.children.set(hashKey, selection);
    return selection;
  }
  getLeafNodes() {
    const result = /* @__PURE__ */ new Set();
    const stack = /* @__PURE__ */ new Set([this]);
    for (const selection of stack) {
      if (selection.children.size === 0) {
        result.add(selection);
      } else {
        for (const [, child] of selection.children) stack.add(child);
      }
    }
    return result;
  }
  toJSON() {
    return this.ancestry.map(({ key, isUnion, input, options }) => {
      if (isUnion) {
        return [key, { isUnion, ...options }];
      } else if (input) {
        return [key, { input }];
      } else {
        return [key];
      }
    });
  }
  fromJSON(json) {
    let node = this;
    for (const [key, options] of json) {
      node = node.getChild(key, options);
    }
    return node;
  }
  get [Symbol.toStringTag]() {
    return "Selection";
  }
  toString() {
    var _a, _b;
    return `Selection(${this.cacheKeys.join(".")}) ${JSON.stringify(
      (_b = (_a = this.input) == null ? void 0 : _a.values) != null ? _b : {}
    )}`;
  }
}

export { Selection };
