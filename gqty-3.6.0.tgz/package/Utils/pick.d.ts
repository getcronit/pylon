import type { Selection } from '../Selection';
/** Similiar to the `select()` helper, but for accessor proxies. */
export declare const pick: (schema: Record<string, any>, selections: Set<Selection>) => Record<string, any>;
