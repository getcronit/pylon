'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const memoize = require('just-memoize');
const ohash = require('ohash');

function _interopDefault (e) { return e && e.__esModule ? e : { 'default': e }; }

const memoize__default = /*#__PURE__*/_interopDefault(memoize);

const hash = memoize__default["default"](
  (...args) => ohash.sha256(ohash.objectHash(args, { unorderedObjects: false })).replace(/^(\d)/, "a$1")
);

exports.hash = hash;
