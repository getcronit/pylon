export type PlainObject = Record<string | number | symbol, unknown>;
export declare const isObject: (v: unknown) => v is Record<string, unknown>;
export declare const isPlainObject: (v: unknown) => v is PlainObject;
export declare function isEmptyObject(obj: object): boolean;
export interface ObjectWithType<Typename extends string = string> extends Record<string, unknown> {
    __typename: Typename;
}
export declare const isObjectWithType: <T extends ObjectWithType>(v: unknown) => v is T;
/**
 * Similar to `just-extend(true, ...)` but circular references aware.
 */
export declare function deepAssign<T extends object>(target: object, sources: (object | undefined | null)[], onConflict?: (targetValue: object, sourceValue: object) => object | void): T;
