export type DeferredIterator<T> = AsyncGenerator<T, void, unknown> & {
    send: (value: T) => void;
    complete: () => void;
};
export declare const createDeferredIterator: <T>() => DeferredIterator<T>;
