const isObject = (v) => v != null && typeof v === "object";
const isPlainObject = (v) => isObject(v) && !Array.isArray(v);
function isEmptyObject(obj) {
  for (const _i in obj) return false;
  return true;
}
const isObjectWithType = (v) => isPlainObject(v) && typeof v.__typename === "string";
function deepAssign(target, sources, onConflict) {
  for (const source of sources) {
    for (const [sourceKey, sourceValue] of Object.entries(source || {})) {
      if (sourceKey in target) {
        const targetValue = Reflect.get(target, sourceKey);
        if (sourceValue === targetValue) continue;
        if (isObject(sourceValue) && isObject(targetValue)) {
          const onConflictResult = onConflict == null ? void 0 : onConflict(targetValue, sourceValue);
          if (onConflictResult === void 0) {
            Reflect.set(
              target,
              sourceKey,
              deepAssign(targetValue, [sourceValue], onConflict)
            );
          } else {
            Reflect.set(target, sourceKey, onConflictResult);
          }
          continue;
        }
      }
      Reflect.set(target, sourceKey, sourceValue);
    }
  }
  return target;
}

export { deepAssign, isEmptyObject, isObject, isObjectWithType, isPlainObject };
