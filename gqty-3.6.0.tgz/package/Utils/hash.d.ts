/**
 * Memoized hash function, with a prefix to avoid starting with a number.
 */
export declare const hash: (...args: unknown[]) => string;
