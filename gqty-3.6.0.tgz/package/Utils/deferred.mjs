import createDeferred from 'p-defer';

const asyncItDoneMessage = { done: true };
const createDeferredIterator = () => {
  let deferred = createDeferred();
  const events = [];
  const next = async () => {
    const value = events.shift();
    if (value !== void 0) {
      return { value, done: false };
    }
    if (!deferred) {
      return asyncItDoneMessage;
    }
    await deferred.promise;
    return next();
  };
  return {
    send: (value) => {
      events.push(value);
      deferred == null ? void 0 : deferred.resolve();
      deferred = createDeferred();
    },
    complete: () => {
      deferred == null ? void 0 : deferred.resolve();
      deferred = void 0;
    },
    next,
    return: async () => {
      events.splice(0, events.length);
      deferred == null ? void 0 : deferred.resolve();
      deferred = void 0;
      return asyncItDoneMessage;
    },
    throw: async (error) => {
      events.splice(0, events.length);
      deferred == null ? void 0 : deferred.reject(error);
      deferred = void 0;
      return asyncItDoneMessage;
    },
    [Symbol.asyncIterator]() {
      return this;
    },
    async [Symbol.asyncDispose]() {
      await this.return();
    }
  };
};

export { createDeferredIterator };
