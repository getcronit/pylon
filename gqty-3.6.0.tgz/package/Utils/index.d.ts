export * from './hash';
export * from './object';
export * from './pick';
export declare const isInteger: (v: unknown) => v is number;
