export { hash } from './hash.mjs';
export { deepAssign, isEmptyObject, isObject, isObjectWithType, isPlainObject } from './object.mjs';
export { pick } from './pick.mjs';

const isInteger = (v) => Number.isInteger(v);

export { isInteger };
