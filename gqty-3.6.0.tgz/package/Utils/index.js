'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const hash = require('./hash.js');
const object = require('./object.js');
const pick = require('./pick.js');

const isInteger = (v) => Number.isInteger(v);

exports.hash = hash.hash;
exports.deepAssign = object.deepAssign;
exports.isEmptyObject = object.isEmptyObject;
exports.isObject = object.isObject;
exports.isObjectWithType = object.isObjectWithType;
exports.isPlainObject = object.isPlainObject;
exports.pick = pick.pick;
exports.isInteger = isInteger;
