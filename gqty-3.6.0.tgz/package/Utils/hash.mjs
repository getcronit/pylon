import memoize from 'just-memoize';
import { sha256, objectHash } from 'ohash';

const hash = memoize(
  (...args) => sha256(objectHash(args, { unorderedObjects: false })).replace(/^(\d)/, "a$1")
);

export { hash };
