export type RetryOptions = {
    /**
     * Amount of retries to be made
     *
     * > __It has to be >= 1__
     * @default 3
     */
    maxRetries?: number;
    /**
     * Amount of milliseconds between each attempt, it can be a static number,
     * or a function based on the attempt number
     *
     * @default (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000)
     */
    retryDelay?: number | ((attemptIndex: number) => number);
}
/** If retries should be enabled
 * @default true
 */
 | boolean
/** Amount of retries to be made
 *
 * > It has to be >= 0
 * @default 3
 */
 | number;
export interface RetryConfigState {
    /**
     * Error incremental attempt index
     *
     * You shouldn't set it manually
     * @default 0
     *
     * @private
     */
    attemptIndex?: number;
    /**
     * Function to be executed on approved retry attempt
     */
    onRetry: (attemptIndex: number) => Promise<void>;
    /**
     * Function to be executed on the last try
     */
    onLastTry?: (attemptIndex: number) => Promise<void>;
}
export declare function doRetry(options: RetryOptions, state: RetryConfigState): void;
