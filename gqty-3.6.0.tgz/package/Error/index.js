'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const retry = require('./retry.js');

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class GQtyError extends Error {
  constructor(message, { graphQLErrors, otherError } = {}) {
    super(message);
    __publicField(this, "name", "GQtyError");
    __publicField(this, "graphQLErrors");
    __publicField(this, "otherError");
    if (graphQLErrors) this.graphQLErrors = graphQLErrors;
    if (otherError !== void 0) this.otherError = otherError;
  }
  toJSON() {
    return {
      message: this.message,
      graphQLErrors: this.graphQLErrors,
      otherError: this.otherError
    };
  }
  static create(error) {
    let newError;
    if (error instanceof GQtyError) {
      newError = error;
    } else if (error instanceof Error) {
      newError = Object.assign(new GQtyError(error.message), error);
    } else {
      newError = new GQtyError("Unexpected error type", {
        otherError: error
      });
    }
    return newError;
  }
  static fromGraphQLErrors(errors) {
    return new GQtyError(
      errors.length === 1 && errors[0].message || (process.env.NODE_ENV === "production" ? `GraphQL Errors` : "GraphQL Errors, please check .graphQLErrors property"),
      { graphQLErrors: errors }
    );
  }
}

exports.doRetry = retry.doRetry;
exports.GQtyError = GQtyError;
