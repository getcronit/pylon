import type { GraphQLError } from 'graphql';
export type GQtyErrorOptions = {
    graphQLErrors?: GQtyError['graphQLErrors'];
    otherError?: GQtyError['otherError'];
};
export declare class GQtyError extends Error {
    readonly name = "GQtyError";
    graphQLErrors?: ReadonlyArray<GraphQLError>;
    otherError?: unknown;
    constructor(message: string, { graphQLErrors, otherError }?: GQtyErrorOptions);
    toJSON(): {
        message: string;
        graphQLErrors: readonly GraphQLError[] | undefined;
        otherError: unknown;
    };
    static create(error: unknown): GQtyError;
    static fromGraphQLErrors(errors: readonly GraphQLError[]): GQtyError;
}
export * from './retry';
